#!/bin/bash
#PATHS
TRACKINGPATH="/afs/cern.ch/work/g/gauzinge/public/Tracking"
TMPPATH="/afs/cern.ch/work/g/gauzinge/public/Tracking/tmp"
HISTOPATH="/afs/cern.ch/work/g/gauzinge/public/Tracking/histo"

#--TESTBEAM
TESTBEAM="102012"

# -- choose set of runs to be processed
RUNSET="5683 5695"

echo Setting environment variables!
source /afs/cern.ch/sw/lcg/contrib/gcc/4.6/x86_64-slc5-gcc46-opt/setup.sh
source /afs/cern.ch/sw/lcg/app/releases/ROOT/5.34.05/x86_64-slc5-gcc46-dbg/root/bin/thisroot.sh
export PATH=/afs/cern.ch/sw/lcg/external/CMake/2.8.8/x86_64-slc5-gcc46-opt/bin/:$PATH

# source /afs/cern.ch/project/eos/installation/cms/etc/setup.sh
# source /afs/cern.ch/sw/lcg/contrib/gcc/4.6.3/x86_64-slc6-gcc46-opt/setup.sh
# source /afs/cern.ch/sw/lcg/app/releases/ROOT/5.34.05/x86_64-slc6-gcc46-dbg/root/bin/thisroot.sh
# export PATH=/afs/cern.ch/sw/lcg/external/CMake/2.8.8/x86_64-slc6-gcc46-opt/bin/:$PATH

echo Initializing ILCSOFT!
source /afs/cern.ch/work/g/gauzinge/public/ilcsoft/v01-16/init_ilcsoft.sh
# source /afs/cern.ch/work/g/gauzinge/public/ilcsoft/v01-17-01/init_ilcsoft.sh

echo "set of runs to be processed: $RUNSET"
# -- choose config file (should be placed in pysub/config/)
CONFIG=$TRACKINGPATH"/config/"$TESTBEAM"_config.cfg"
echo The CONFIG File is: $CONFIG
# -----------------------------------------------------------------------------
# telescope planes
# TELPLANES="0 1 2 3 4 5 6 7"
# fixed planes for telescope alignment
# TELPLANESFIXED="0 1 6 7"
export logs="/afs/cern.ch/work/g/gauzinge/public/Tracking/logs/"
#
# -----------------------------------------------------------------------------
for RUN in $RUNSET;
do
echo "Running full analysis chain for run $RUN"
# if [ -d $logs ]; then
# echo "Writing logfiles to $logs"
# else
# echo "Directory $logs/ does not exist. Creating..."
# mkdir $logs
# echo "Writing logfiles to $logs"
# fi
# rm -rf $logs/*.$RUN*.log

# creating folder for ilc intermediate files
echo "Creating tmp Directory for ILC Files: "$TMPPATH
mkdir $TMPPATH
echo "Copying RawData files to "$TMPPATH
for FILE in 0 1 2 3 4 5 6 7 8 9
do
cmsStage "/store/user/gauzinge/RawData/RU000"$RUN"_00"$FILE".root" $TMPPATH
if [ "$?" -ne "0" ]; then #if error break -> if no error, continue, else break
	echo "File does not exist, stopping!"
	break
else {
	echo "Adding file "$FILE
     } 
fi
done
echo "Done!"
echo "Creating temporary histogram directory: histo"
mkdir $HISTOPATH

# standard convertion from RAW to LCIO data format
echo Submitting Converter $RUN
$TRACKINGPATH/submit-converter.py $RUN --config=$CONFIG
# > $logs/converter.$RUN.log

# Calculate Pedestals from Data file or pedestal file
echo Submitting Pedestal Calculator $RUN
$TRACKINGPATH/submit-pedestal.py $RUN --config=$CONFIG
# > $logs/pedestal.$RUN.log

# ClusterFinder
echo Submitting Cluster Finder &RUN
$TRACKINGPATH/submit-clusearch.py $RUN --config=$CONFIG -p $RUN 
# > $logs/clusearch.$RUN.log

# Cluster Filter allows to make cuts and filter clusters!
echo Submitting Cluster Filter $RUN
$TRACKINGPATH/submit-filter.py $RUN -p $RUN --config=$CONFIG
# > $logs/filter.$RUN.log# 

# Eta correction
echo Submitting Eta Calculator $RUN
$TRACKINGPATH/submit-eta.py run000$RUN-filter-p000$RUN.slcio --config=$CONFIG -o run000$RUN

#Hitmaker
echo  Submitting Hitmaker $RUN
$TRACKINGPATH/submit-hitmaker.py run000$RUN-filter-p000$RUN.slcio -e run000$RUN-eta-db.slcio --config=$CONFIG -o run000$RUN
# > $logs/hitmaker.$RUN.log

# align all Planes!
echo Submitting Alignment $RUN
$TRACKINGPATH/submit-align.py -o run000$RUN run000$RUN-hit.slcio  --config=$CONFIG
# > $logs/align.$RUN.log

# -- Finally! Fit the tracks! --
echo Submitting Trackfitter $RUN
$TRACKINGPATH/submit-fitter.py -o run000$RUN run000$RUN-prealigned_hit.slcio -a run000$RUN-align-db.slcio --config=$CONFIG
#  > $logs/fitter.$RUN.log

echo "done for run $RUN"

echo "Copying TrackFile to eos /eos/cms/store/user/gauzinge/Tracking/Tracks"
cp $TMPPATH/TelescopeTracks_run000$RUN.root $TRACKINGPATH/Tracks/
cmsStage -f $TMPPATH/TelescopeTracks_run000$RUN.root /store/user/gauzinge/TrackData/
echo "Done!"
echo "Copying HitFile to eos /eos/cms/store/user/gauzinge/Tracking/Hits"
cp $TMPPATH/TelescopeHits_run000$RUN.root $TRACKINGPATH/Hits/

echo "CLEANING UP LOG and STEERING FILES!"
rm $TRACKINGPATH/eta-run*
rm $TRACKINGPATH/converter*
rm $TRACKINGPATH/clusearch*
rm $TRACKINGPATH/filter*
rm $TRACKINGPATH/hitmakerN*
rm $TRACKINGPATH/pedestal*
rm $TRACKINGPATH/millepede*
rm $TRACKINGPATH/fitter*
rm $TRACKINGPATH/align*
echo "Cleaning up /tmp directory"
rm -rfv $TMPPATH
echo "Removing /histo directory"
rm -rfv $HISTOPATH
# echo "Removing /logs directory"
# rm -rfv $logs
done


