#!/bin/sh

export WORKSPACE=`pwd`
export TB_ANALYSIS=${WORKSPACE}   
export ILCSOFT=${TB_ANALYSIS}/ilcsoft

echo "#!/bin/sh " >& env.sh
echo "export WORKSPACE=\`pwd\`" >> env.sh
echo "export TB_ANALYSIS=${TB_ANALYSIS} " >> env.sh
echo "export ILCSOFT=\${TB_ANALYSIS}/ilcsoft " >> env.sh
echo "cd \$ILCSOFT/v01-16/Eutelescope/HEAD/ " >> env.sh
echo "source build_env.sh " >> env.sh
echo "cd \${WORKSPACE} " >> env.sh

#### Install EuTelescope
cd $TB_ANALYSIS
#svn co https://svnsrv.desy.de/public/ilctools/ilcinstall/tags/v01-16  ilcinstall_v01-16
cd ilcinstall_v01-16
wget http://atlas.desy.de/ibl/EUTelescope/installation-cfg-files/v01-16/release-ilcsoft.cfg .
mv release-ilcsoft.cfg releases/v01-16
wget http://atlas.desy.de/ibl/EUTelescope/installation-cfg-files/v01-16/release-versions.py .
sed 's/ilcsoft_install_prefix =/ilcsoft_install_prefix = "${ILCSOFT}"\n#/g' release-versions.py >& release-versions_temp.py
mv release-versions_temp.py releases/v01-16/release-versions.py
sed 's/svn.hepforge.org\/eudaq/eudaq.hepforge.org\/svn/g' ilcsoft/eutelescope.py >& eutelescope_temp.py
mv eutelescope_temp.py ilcsoft/eutelescope.py

./ilcsoft-install ./releases/v01-16/release-ilcsoft.cfg -i

cd $ILCSOFT/v01-16/Eutelescope/v00-08-00/
source build_env.sh

cd $EUTELESCOPE
svn checkout http://svnsrv.desy.de/public/MillepedeII/tags/V03-04-04 MillepedeII
cd MillepedeII
make -j 4
cd $EUTELESCOPE/bin
ln -sf $ILCSOFT/v01-16/Eutelescope/v00-08-00/MillepedeII/pede .

cd ${EUTELESCOPE}
svn co http://eudaq.hepforge.org/svn/trunk eudaq/trunk
cd eudaq/trunk/main/
sed 's/USE_LCIO := 0/USE_LCIO := 1/g' Makefile | sed 's/USE_EUTELESCOPE := 0/USE_EUTELESCOPE := 1/g' >& Makefile_temp
mv Makefile_temp Makefile
make clean
make -j 4


