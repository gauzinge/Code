#include <TFile.h>
#include <TTree.h>
#include <TBranch.h>
#include <iostream>
#include <vector>
#include <dirent.h>
#include <string>


std::vector<std::string> read_directory(std::string folder) {
    std::cout << "Reading Directory: " << folder << std::endl;
    std::vector<std::string> filelist;
    std::string foldername = folder;
    DIR           *d;
    struct dirent *dir;
    //    std::vector<std::string> filelist;
    int counter=0;
    d = opendir(foldername.c_str());
    if (d) {
               std::cout << "The Foldername is: " << foldername << "/" << std::endl;
        while ((dir = readdir(d)) != NULL)
        {
            if ( strlen(dir->d_name) > 5 ) {
				// std::cout << dir->d_name << std::endl;
                // std::string name = folder;  //used to be "Exported"
//                 name += "/";
//                 name += dir->d_name;
				std::string name = dir->d_name;
                std::string extension = ".root";
                if (name.find(extension) != std::string::npos) {
                    filelist.push_back(name);
                    counter++;
                    std::cout<< "Found file: " << name << std::endl;
                }
            }
        }
        closedir(d);
    } else std::cout << "[ERROR] The directory " << foldername << " does not exist!" << std::endl;
    return filelist;
}

void copy_tree()
{
	int EventNumber;
	int adc[390];
	double zPosition;
	std::vector<std::string> filelist = read_directory("/afs/cern.ch/work/g/gauzinge/public/eos/cms/store/user/gauzinge/MssdData/");
	for (std::vector<std::string>::iterator files = filelist.begin(); files != filelist.end(); files++)
	{
		int run_number;
		std::string run_nr_string = files->substr(2,4);
		std::cout << run_nr_string << std::endl;
		// std::istringstream (run_nr_string) >> run_number;
		run_number = atoi(run_nr_string.c_str());
		if (run_number <= 4801) {
		std::string filename = "/afs/cern.ch/work/g/gauzinge/public/eos/cms/store/user/gauzinge/MssdData/" + *files /*+ "?eos.bookingsize=1"*/;
		TFile* oldfile = TFile::Open(filename.c_str());
		// std::cout << filename << std::endl;
		 
		TTree *oldtree = (TTree*)oldfile->Get("DUTData");
			
		//Assign Branches to variables DUT (Class Members)
		oldtree->SetBranchAddress("EventNo",&EventNumber);
		oldtree->SetBranchAddress("ADCValues",adc);
		oldtree->SetBranchAddress("DUTzPosition",&zPosition);
		oldtree->SetBranchStatus("*",0);
		oldtree->SetBranchStatus("EventNo",1);
		oldtree->SetBranchStatus("ADCValues",1);
		oldtree->SetBranchStatus("DUTzPosition",1);
		   

		//Create a new file + a clone of old tree in new file
		std::string new_filename = "/afs/cern.ch/work/g/gauzinge/public/Mssd_new/" + *files;
			
		TFile *newfile = TFile::Open(new_filename.c_str(),"RECREATE");
		TTree *newtree = oldtree->CloneTree();

		newtree->Print();
		newfile->Write();
		newfile->ls();
		delete oldfile;
		delete newfile;
	}
	}
		 
}
