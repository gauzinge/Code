#!/bin/bash

RUNSET="3867 3868 3869 3870 3871 3872 3873 3874 3875 3876 3877 3878 3879 3882 3883 3884 3885 3886 3887 3888 3889 3890"


FILES="";
for RUN in $RUNSET; do
FILE="/afs/cern.ch/work/v/vbox/public/native/RU000$RUN*"
echo 'Appending Data file for Run ' $RUN 
FILES=$FILE" $FILES"
done
echo cp -v $FILES /afs/cern.ch/work/g/gauzinge/public/eos/cms/store/user/gauzinge/RawData/
cp -v $FILES /afs/cern.ch/work/g/gauzinge/public/eos/cms/store/user/gauzinge/RawData/
# echo 'Don t forget to harvest RESULTS and remove native Data'
