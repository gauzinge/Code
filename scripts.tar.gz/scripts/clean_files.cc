#include <TFile.h>
#include <TTree.h>
#include <TBranch.h>
#include <iostream>
#include <vector>
#include <dirent.h>
#include <string>

std::vector<std::string> read_directory(std::string folder) {
    std::cout << "Reading Directory: " << folder << std::endl;
    std::vector<std::string> filelist;
    std::string foldername = folder;
    DIR           *d;
    struct dirent *dir;
    //    std::vector<std::string> filelist;
    int counter=0;
    d = opendir(foldername.c_str());
    if (d) {
               std::cout << "The Foldername is: " << foldername << "/" << std::endl;
        while ((dir = readdir(d)) != NULL)
        {
            if ( strlen(dir->d_name) > 5 ) {
				// std::cout << dir->d_name << std::endl;
                // std::string name = folder;  //used to be "Exported"
//                 name += "/";
//                 name += dir->d_name;
				std::string name = dir->d_name;
                std::string extension = ".root";
                if (name.find(extension) != std::string::npos) {
                    filelist.push_back(name);
                    counter++;
                    std::cout<< "Found file: " << name << std::endl;
                }
            }
        }
        closedir(d);
    } else std::cout << "[ERROR] The directory " << foldername << " does not exist!" << std::endl;
    return filelist;
}

void clean_files()
{
    std::vector<std::string> filelist = read_directory("/afs/cern.ch/work/g/gauzinge/public/eos/cms/store/user/gauzinge/MssdData/");
	 for (std::vector<std::string>::iterator files = filelist.begin(); files != filelist.end(); files++)
	 {
		 std::string filename = "root://eoscms.cern.ch//eos/cms/store/user/gauzinge/MssdData/" + *files + "?eos.bookingsize=1";
		 TFile* datafile = TFile::Open(TFile::AsyncOpen(filename.c_str(),"UPDATE"));
		 std::cout << filename << std::endl;
		 
			// std::string pedenoisetree = "DUTPedeNoise;*";
			// std::string clustertree = "ClusterData;*";
			// std::string alignmenttree = "AlignmentConstants;*";
			// std::string trackhittree = "Trackhits;*";
			// std::string ontracktree = "onTrackClusters;*";
			// std::string dummytree = "dummytree;*";
		 
		 //Delete Signal Branch from DUTData tree!!!
			
			gDirectory->Delete("DUTPedeNoise;*");
			gDirectory->Delete("ClusterData;*");
			gDirectory->Delete("AlignmentConstants;*");
			gDirectory->Delete("Trackhits;*");
			gDirectory->Delete("onTrackClusters;*");
			gDirectory->Delete("dummytree;*");
			std::cout << "Successfully deleted Cluster, Alignment and Collection trees!" << std::endl;
			datafile->Close();
	 }
}