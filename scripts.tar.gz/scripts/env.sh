#!/bin/sh 
export WORKSPACE=`pwd`
export TB_ANALYSIS=/afs/cern.ch/work/g/gauzinge/public 
export ILCSOFT=${TB_ANALYSIS}/ilcsoft 
cd $ILCSOFT/v01-16/Eutelescope/HEAD/ 
source build_env.sh 
cd ${WORKSPACE} 
