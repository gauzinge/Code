//
//  style.h
//  
//
//  Created by Georg Auzinger on 29.04.13.
//
//

#ifndef ____style__
#define ____style__

#include <iostream>
#include "TROOT.h"
#include "TStyle.h"

void set_plotstyle();
#endif /* defined(____style__) */
