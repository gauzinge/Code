#ifndef EUTELCMSSTRIPREADER_H
#define EUTELCMSSTRIPREADER_H

// personal includes ".h"

// marlin includes ".h"
#include "marlin/DataSourceProcessor.h"

// lcio includes <.h>
#include <Exceptions.h>

// system includes <>
#include <string.h>

namespace eutelescope
{

  class CMSStripReader: public marlin::DataSourceProcessor 
   {
     public:
    //! Returns a new instance of EUTelApplyAlignmentProcessor
    /*! This method returns an new instance of the this processor.  It
     *  is called by Marlin execution framework and it shouldn't be
     *  called/used by the final user.
     *
     *  @return a new EUTelApplyAlignmentProcessor.
     */
    virtual Processor * newProcessor() {
      return new CMSStripReader;
    }

     //! Default constructor
     CMSStripReader();
//     virtual CMSStripReader * newProcessor ();
     virtual void readDataSource (int Ntrig);
     virtual void init ();
     virtual void end ();
 
   protected:
 
       std::string _filePath;
       int _noOfFEDs;
       int _noOfFEDChannels;
       int _runNumber;
       int _noOfStrips;
       int _noOfStripsInDUTRegion;
       std::string _connectionMap;
       std::string _DUTs;

       short *_buffer;
       std::vector<int >_excludePlane;
       std::vector<int >_setupPlane;
       //! DEBUG
       bool _debugSwitch; 
   };
   CMSStripReader gCMSStripReader;
 
 
}                               // end namespace eutelescope
#endif
