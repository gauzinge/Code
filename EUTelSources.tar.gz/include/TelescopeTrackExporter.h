#ifndef TelescopeTrackExporter_h
#define TelescopeTrackExporter_h 1

#include "marlin/Processor.h"
#include "lcio.h"
#include <string>
#include <EVENT/LCRunHeader.h>
#include <IMPL/LCCollectionVec.h>
#include "TFile.h"
#include "TTree.h"

// gear includes <.h>
//#include <gear/SiPlanesParameters.h>
//#include <gear/SiPlanesLayerLayout.h>



using namespace lcio ;
using namespace marlin ;


/**  Hit Faker for Strip sensors.
 * 
 *  Interpolates missing coordinate if strip telescope is used. To be used after HitMaker.
 *  If compiled with MARLIN_USE_AIDA 
 *  it creates a histogram (cloud) of the MCParticle energies.
 * 
 *  <h4>Input - Prerequisites</h4>
 *  Needs the collection of MCParticles.
 *
 *  <h4>Output</h4> 
 *  A histogram.
 * 
 * @param CollectionName Name of the MCParticle collection
 * 
 * @author A. Nuernberg, KIT
 * @version $Id: CosmicHitFaker.h,v 1.0 2012-03-20 12:57:39 nuernberg Exp $ 
 */

class TelescopeTrackExporter : public Processor {
  
 public:
  
  virtual Processor*  newProcessor() { 
      return new TelescopeTrackExporter;
  }
  
  
  TelescopeTrackExporter() ;
  
  /** Called at the begin of the job before anything is read.
   * Use to initialize the processor, e.g. book histograms.
   */
  virtual void init();
  
  /** Called for every run.
   */
  virtual void processRunHeader( LCRunHeader* run ) ;
  
  /** Called for every event - the working horse.
   */
  virtual void processEvent( LCEvent * event ) ; 
  
  
  virtual void check( LCEvent * evt ) ; 
  
  
  /** Called after data processing for clean up.
   */
  virtual void end() ;
  
  
 protected:

  /** Input collection name.
   */
//  std::string _colName ;

  int _nRun ;
  int _nEvt ;
    double xSlope, xIntercept;
    double ySlope, yIntercept;
    int evtno;
    int evtwotrack;
    int evtwtrack;
    TFile* file;
    TTree* TelescopeTrack;
   
    //! Input collection name.
    /*! This is the name of the input hit collection DUTHit
     */
    
    //! Input collection name.
    /*! This is the name of the input Track Collection Name TelescopeTracks
     */
    std::string _inputTrackCollectionName;
    
    //Name of Root File
    std::string _rootFile;    
    } ;

#endif



