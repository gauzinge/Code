#ifndef DUTDataExporter_h
#define DUTDataExporter_h 1

#include "marlin/Processor.h"
#include "marlin/Exceptions.h"
#include "lcio.h"
#include <EVENT/LCRunHeader.h>
#include <IMPL/LCCollectionVec.h>

// gear includes <.h>
#include <gear/SiPlanesParameters.h>
#include <gear/SiPlanesLayerLayout.h>

// ROOT includes:
#include "TVector3.h"
#include "TGraph.h"
#include "TFile.h"
#include "TTree.h"
#include "TF1.h"
#include "TBranch.h"

// system includes 
#include <string>
#include <map>

using namespace lcio ;
using namespace marlin ;



class DUTDataExporter : public Processor {
  
 public:
  
  virtual Processor*  newProcessor() { 
      return new DUTDataExporter;
  }
  
  
  DUTDataExporter() ;
  
  /** Called at the begin of the job before anything is read.
   * Use to initialize the processor, e.g. book histograms.
   */
  virtual void init();
  
  /** Called for every run.
   */
  virtual void processRunHeader( LCRunHeader* run ) ;

  
  /** Called for every event - the working horse.
   */
  virtual void processEvent( LCEvent * event ) ; 
  
  
  virtual void check( LCEvent * evt ) ; 
  
  
  /** Called after data processing for clean up.
   */
  virtual void end() ;
  
  void initializeGeometry( LCEvent * event ) throw ( marlin::SkipEventException );  
 
 
 protected:

  /** Input collection name.
   */
  std::string _colName ;

  int _nRun ;
  int _nEvt ;
//    
//    double xPos, zPos;
//    int evtno;
//    TFile* file;
//    TTree* DutHit;
    
    //! Map relating ancillary collection position and sensorID
    /*! The first element is the sensor ID, while the second is the
     *  position of such a sensorID in all the ancillary collections
     *  (noise, pedestal and status).
     */
    std::map< int, int > _ancillaryIndexMap;
    
    //! Map relating the sensorID and pixels
    std::map< int, unsigned int > _noOfPixelMap;
    
    //! Map relating the sensorID and pixels per row
    std::map< int, unsigned int > _noOfPixelPerRowMap;
    
    //! Map relating the sensorID and the rows
    std::map< int, unsigned int > _noOfRowMap;
    
    //! Geometry ready switch
    /*! This boolean reveals if the geometry has been properly
     *  initialized or not.
     */
    bool _isGeometryReady;

    
    //This is the Name of the RawData Collection Name
    std::string _inputRawDataCollectionName;
    

    
    //Pedestal Collection Name
    std::string _pedestalCollectionName;
    
    //Noise Collection Name
    std::string _noiseCollectionName;

    //DUT ID
    int _DUT_ID;
    
    //Name of Root File
    std::string _rootFile;

    //! Output collection name.
    /*! This is the name of the output hit collection.
     */
    //std::string _outputHitCollectionName;

    //! Silicon planes parameters as described in GEAR
    /*! This structure actually contains the following:
     *  @li A reference to the telescope geoemtry and layout
     *  @li An integer number saying if the telescope is w/ or w/o DUT
     *  @li An integer number saying the number of planes in the
     *  telescope.
     *
     *  This object is provided by GEAR during the init() phase and
     *  stored here for local use.
     */
    gear::SiPlanesParameters * _siPlanesParameters;

    //! Silicon plane layer layout
    /*! This is the real geoemetry description. For each layer
     *  composing the telescope the relevant information are
     *  available.
     *
     *  This object is taken from the _siPlanesParameters during the
     *  init() phase and stored for local use
     */
    gear::SiPlanesLayerLayout * _siPlanesLayerLayout;

    //! An array with the Z position of planes
//    double * _siPlaneZPosition;
    

    int DUTevtno;
    int DUTadc_values[390];
    float DUTpedestal_values[390];
    float DUTnoise_values[390];
    double zPosition;
    
    TFile* Hitfile;
    TTree* DUTData;
    TTree* DUTPedeNoise;
    TBranch* EventNo;
    TBranch* DUTzPosition;

  
    TBranch* adc_values;
    TBranch* pedestal_values;
    TBranch* noise_values;
    
} ;

#endif



