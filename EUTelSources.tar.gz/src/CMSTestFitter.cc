//
//  CMSTestFitter.cc
//  
//
//  Created by Georg Auzinger on 22.03.13.
//
//

#include "CMSTestFitter.h"
#include <iostream>
#include <string>

#include <EVENT/LCCollection.h>
#include <EVENT/MCParticle.h>

// ----- include for verbosity dependend logging ---------
#include "marlin/VerbosityLevels.h"

#ifdef MARLIN_USE_AIDA
#include <marlin/AIDAProcessor.h>
#include <AIDA/IHistogramFactory.h>
#include <AIDA/ICloud1D.h>
//#include <AIDA/IHistogram1D.h>
#endif // MARLIN_USE_AIDA

// gear includes <.h>
#include <gear/GearMgr.h>
#include <gear/SiPlanesParameters.h>

// eutelescope includes ".h"
#include "EUTelAlignmentConstant.h"
#include "EUTELESCOPE.h"
#include "EUTelEventImpl.h"
#include "EUTelRunHeaderImpl.h"
#include "EUTelHistogramManager.h"
#include "EUTelExceptions.h"
#include "EUTelAPIXSparsePixel.h"
#include "EUTelSparseDataImpl.h"
#include "EUTelAPIXSparseClusterImpl.h"

// marlin includes ".h"
#include "marlin/Processor.h"
#include "marlin/Exceptions.h"
#include "marlin/Global.h"

// lcio includes <.h>
#include <UTIL/CellIDEncoder.h>
#include <UTIL/CellIDDecoder.h>
#include <EVENT/LCCollection.h>
#include <EVENT/LCEvent.h>
#include <IMPL/LCCollectionVec.h>
#include <IMPL/TrackerHitImpl.h>
#include <IMPL/TrackImpl.h>
#include <IMPL/TrackerDataImpl.h>
#include <IMPL/LCFlagImpl.h>
#include <Exceptions.h>

// ROOT includes:
#include "TVector3.h"
#include "TGraph.h"
#include "TF1.h"
#include "TF1.h"
#include "TFitResultPtr.h"
#include "TFitResult.h"
#include "TMath.h"



using namespace lcio ;
using namespace marlin ;

using namespace std;
using namespace eutelescope;
using namespace gear;


CMSTestFitter aCMSTestFitter;

CMSTestFitter::CMSTestFitter() : Processor("CMSTestFitter") {
    
    // modify processor description
    _description = "CMSTestFitter searches for Events with a number of Hits corresponding to the number of planes, fits straight lines and exports track parameters and Hits to 2 ROOT Trees!" ;
    
    
    // first of all we need to register the input collection
    registerInputCollection (LCIO::TRACKERHIT, "InputHitCollectionName",
                             "The name of the (aligned) input hit collection",
                             _inputHitCollectionName, string ("hit"));
    
    registerProcessorParameter("Root File","This is the name of the file that will contain the TTrees with Hits and fittd Telescope Tracks (add .root)",
                               _rootFile, static_cast< string > ( "TBData.root" ) );
    
}

void CMSTestFitter::init(){
    //HitExporter
    x0=0,y0=0,z0=0;
    x1=0,y1=0,z1=0;
    x2=0,y2=0,z2=0;
    x3=0,y3=0,z3=0;
    x4=0,y4=0,z4=0;
    x5=0,y5=0,z5=0;
    x6=0,y6=0,z6=0;
    x7=0,y7=0,z7=0;
    //TrackExporter
    xSlope=0, xIntercept=0;
    ySlope=0, yIntercept=0;
    evtno=0;
    evtwotrack=0;
    evtwtrack=0;
    streamlog_out(DEBUG0) << "   init called  " << std::endl ;
    
    file=new TFile(_rootFile.c_str(), "RECREATE");
    if (!file){
        streamlog_out( ERROR4 ) << "Can not create Root file!" << std::endl;
        throw UnknownDataTypeException("SORRY FOR QUITTING!");
    } else if (file->IsZombie()) {
        streamlog_out( ERROR4 ) << "Error opening Root file!" << std::endl;
        throw UnknownDataTypeException("SORRY FOR QUITTING!");
    } else {
        streamlog_out ( MESSAGE ) << "TFile successfully created!" << std::endl;
        
        TelescopeTrack = new TTree ("TelescopeTrack", "TTree with Telescope Tracks in Telescope Frame of Reference");
        //TELESCOPE TRACK
        TelescopeTrack->Branch("EventNo", &evtno,"EventNo/I");
        TelescopeTrack->Branch("xSlope",&xSlope,"xSlope/D");
        TelescopeTrack->Branch("ySlope",&ySlope,"ySlope/D");
        TelescopeTrack->Branch("xIntercept",&xIntercept,"xIntercept/D");
        TelescopeTrack->Branch("yIntercept",&yIntercept,"yIntercept/D");
        
        TelescopeHit = new TTree ("TelescopeHit", "TTree with Telescope Hits in Telescope Frame of Reference");
        TelescopeHit->Branch("EventNo", &evtno,"EventNo/I");
        TelescopeHit->Branch("x0",&x0,"x0/D");
        TelescopeHit->Branch("y0",&y0,"y0/D");
        TelescopeHit->Branch("z0",&z0,"z0/D");
        
        TelescopeHit->Branch("x1",&x1,"x1/D");
        TelescopeHit->Branch("y1",&y1,"y1/D");
        TelescopeHit->Branch("z1",&z1,"z1/D");
        
        TelescopeHit->Branch("x2",&x2,"x2/D");
        TelescopeHit->Branch("y2",&y2,"y2/D");
        TelescopeHit->Branch("z2",&z2,"z2/D");
        
        TelescopeHit->Branch("x3",&x3,"x3/D");
        TelescopeHit->Branch("y3",&y3,"y3/D");
        TelescopeHit->Branch("z3",&z3,"z3/D");
        
        TelescopeHit->Branch("x4",&x4,"x4/D");
        TelescopeHit->Branch("y4",&y4,"y4/D");
        TelescopeHit->Branch("z4",&z4,"z4/D");
        
        TelescopeHit->Branch("x5",&x5,"x5/D");
        TelescopeHit->Branch("y5",&y5,"y5/D");
        TelescopeHit->Branch("z5",&z5,"z5/D");
        
        TelescopeHit->Branch("x6",&x6,"x6/D");
        TelescopeHit->Branch("y6",&y6,"y6/D");
        TelescopeHit->Branch("z6",&z6,"z6/D");
        
        TelescopeHit->Branch("x7",&x7,"x7/D");
        TelescopeHit->Branch("y7",&y7,"y7/D");
        TelescopeHit->Branch("z7",&z7,"z7/D");
    }

    _siPlanesParameters  = const_cast<SiPlanesParameters* > (&(Global::GEAR->getSiPlanesParameters()));
    _siPlanesLayerLayout = const_cast<SiPlanesLayerLayout*> ( &(_siPlanesParameters->getSiPlanesLayerLayout() ));
    
    _planePosition   = new double[8];
    
    for(int ipl=0; ipl <  _siPlanesLayerLayout->getNLayers(); ipl++)
    {
        _planePosition[ipl]=_siPlanesLayerLayout->getLayerPositionZ(ipl);
    }
    // usually a good idea to
    printParameters() ;
}

void CMSTestFitter::processRunHeader( LCRunHeader* run) {
    
    auto_ptr<EUTelRunHeaderImpl> runHeader ( new EUTelRunHeaderImpl( run ));
    runHeader->addProcessor( type() );
    
}


void CMSTestFitter::processEvent( LCEvent * event ) {
    
    
    // this gets called for every event
    // usually the working horse ...
    //-- note: this will not be printed if compiled w/o MARLINDEBUG0=1 !
    
    streamlog_out(DEBUG0) << "   processing event: " << event->getEventNumber()
    << "   in run:  " << event->getRunNumber() << std::endl ;
    
    
    EUTelEventImpl * evt = static_cast<EUTelEventImpl*> (event);
    
    
    if ( evt->getEventType() == kEORE )
    {
        streamlog_out ( DEBUG0 ) << "EORE found: nothing else to do." << endl;
        return;
    }
    else if ( evt->getEventType() == kUNKNOWN )
    {
        streamlog_out ( WARNING2 ) << "Event number " << evt->getEventNumber() << " in run " << evt->getRunNumber()
        << " is of unknown type. Continue considering it as a normal Data Event." << endl;
    }
    
    //GRAPHS for FIT
    TGraph* grx = new TGraph();
    TGraph* gry = new TGraph();
    
    
    // Here the party starts
    if ((file) && (!file->IsZombie())) {
        try
        {
            LCCollectionVec * inputCollectionVec         = dynamic_cast < LCCollectionVec * > (evt->getCollection(_inputHitCollectionName));
//            std::cout<<"DEBUG0 this happens! " << inputCollectionVec->size() << std::endl;
            if (inputCollectionVec->size() == 8) {
//                std::cout << "Found 8 Hits in Event" << std::endl;
//                streamlog_out (DEBUG0) << "Found 8 Hits in Event" << evt->getEventNumber() << std::endl;
                
                for (size_t iHit = 0; iHit < inputCollectionVec->size(); iHit++) {
//                    std::cout<<"DEBUG0 this happens1! " << std::endl;
                    TrackerHitImpl   * inputHit   = dynamic_cast< TrackerHitImpl * >  ( inputCollectionVec->getElementAt( iHit ) ) ;
//                    std::cout<<"DEBUG0 this happens2! " << std::endl;

                    double * inputPosition      = const_cast< double * > ( inputHit->getPosition() ) ;
//                    std::cout<<"DEBUG0 this happens3! " << std::endl;

                    //Now I have the individual hits
                    
                    //Trackfit Part
//                    streamlog_out (DEBUG0) << "new hit x: " << inputPosition[0] << " y: " << inputPosition[1] << " z: " << inputPosition[2] <<endl;
                    if (fabs(inputPosition[0])<1e-5) //rotated sensor
                    {
                        gry->SetPoint(gry->GetN(),inputPosition[2], inputPosition[1]);
//                        streamlog_out (DEBUG0) << "gry set point z:" << inputPosition[2] << " " << inputPosition[1] << endl;
                    }
                    else if (fabs(inputPosition[1])<1e-5) //not rotated sensor
                    {
                        grx->SetPoint(grx->GetN(),inputPosition[2], inputPosition[0]);
//                        streamlog_out (DEBUG0) << "grx set point z:" << inputPosition[2] << " " << inputPosition[0] << endl;
                    }
                    
                    //HitExportPart
                    if (fabs(inputPosition[2]-_planePosition[0])<5) {
                        x0=inputPosition[0];
                        y0=inputPosition[1];
                        z0=inputPosition[2];
//                        streamlog_out (DEBUG0) << "Found hit on plane 0 with " << x0 << " " << y0 << " " << z0 << std::endl;
                    }
                    else if (fabs(inputPosition[2]-_planePosition[1])<5) {
                        x1=inputPosition[0];
                        y1=inputPosition[1];
                        z1=inputPosition[2];
//                        streamlog_out (DEBUG0) << "Found hit on plane 1 with " << x1 << " " << y1 << " " << z1 << std::endl;
                    }
                    else if (fabs(inputPosition[2]-_planePosition[2])<5) {
                        x2=inputPosition[0];
                        y2=inputPosition[1];
                        z2=inputPosition[2];
//                        streamlog_out (DEBUG0) << "Found hit on plane 2 with " << x2 << " " << y2 << " " << z2 << std::endl;
                    }
                    else if (fabs(inputPosition[2]-_planePosition[3])<5) {
                        x3=inputPosition[0];
                        y3=inputPosition[1];
                        z3=inputPosition[2];
//                        streamlog_out (DEBUG0) << "Found hit on plane 3 with " << x3 << " " << y3 << " " << z3 << std::endl;
                    }
                    else if (fabs(inputPosition[2]-_planePosition[4])<5) {
                        x4=inputPosition[0];
                        y4=inputPosition[1];
                        z4=inputPosition[2];
//                        streamlog_out (DEBUG0) << "Found hit on plane 4 with " << x4 << " " << y4 << " " << z4 << std::endl;
                    }
                    else if (fabs(inputPosition[2]-_planePosition[5])<5) {
                        x5=inputPosition[0];
                        y5=inputPosition[1];
                        z5=inputPosition[2];
//                        streamlog_out (DEBUG0) << "Found hit on plane 5 with " << x5 << " " << y5 << " " << z5 << std::endl;
                    }
                    else if (fabs(inputPosition[2]-_planePosition[6])<5) {
                        x6=inputPosition[0];
                        y6=inputPosition[1];
                        z6=inputPosition[2];
//                        streamlog_out (DEBUG0) << "Found hit on plane 6 with " << x6 << " " << y6 << " " << z6 << std::endl;
                    }
                    else if (fabs(inputPosition[2]-_planePosition[7])<5) {
                        x7=inputPosition[0];
                        y7=inputPosition[1];
                        z7=inputPosition[2];
//                        streamlog_out (DEBUG0) << "Found hit on plane 7 with " << x7 << " " << y7 << " " << z7 << std::endl;
                        
                        
                    }
                    
                    if (grx->GetN() > 3 && gry->GetN() > 3)
                    {
                        grx->Fit("pol1","Q");
                        gry->Fit("pol1","Q");
                        
                        TF1* xfit = grx->GetFunction("pol1");
                        TF1* yfit = gry->GetFunction("pol1");
                        
                        //now the fitted lin. Function is in xfit and yfit
                        xSlope = xfit->GetParameter(1);
                        xIntercept = xfit->GetParameter(0);
                        ySlope = yfit->GetParameter(1);
                        yIntercept = yfit->GetParameter(0);
//                        evtno = evt->getEventNumber();
                        
                        TelescopeTrack->Fill(); //Fill Tree
                        TelescopeHit->Fill();
                        file->Flush();
                        evtwtrack++;
                        
                    }
                    else
                    {
//                        streamlog_out (DEBUG0) << "Hits can not be converted, skipping event!" << endl;
                    }
                    
                    delete grx; delete gry;
                }
                
            }
        }
        catch (DataNotAvailableException& e) {
            streamlog_out  ( WARNING2 ) <<  "No input collection found on event " << event->getEventNumber()
            << " in run " << event->getRunNumber() << endl;
            evtwotrack++;
        }
        _nEvt ++ ;
    }
}


void CMSTestFitter::end(){
    if ((file) && (!file->IsZombie()))
    {
        
        file->Write();
        file->Close();
        streamlog_out (MESSAGE) << "TFile Successfully written and closed!" << std::endl;
        streamlog_out (MESSAGE) << evtwtrack << " Events w tracks found!" << std::endl;
        streamlog_out (MESSAGE) << evtwotrack << " Events w/o tracks found!" << std::endl;
        
    }
    
    streamlog_out (MESSAGE) << "TelescopeTrackExporter::end()  " << name()
    << " processed " << _nEvt << " events." << std::endl ;
    
}

