/*========================================================================*/
/*          CMSStrip file converter (root->LCIO)                          */
/*          Author: Alexander Dierl                                       */
/*                (alexander.dierlamm@kit.edu                             */
/*          Created   23 feb 2012                                         */
/*          Based on the CMSPixelReader  by Simon Spannagel               */
/*          Modified                                                      */
/*========================================================================*/

// user includes
#include "CMSStripReader.h"
#include "EUTelRunHeaderImpl.h"
#include "EUTelEventImpl.h"


// marlin includes
#include "marlin/Processor.h"
#include "marlin/DataSourceProcessor.h"
#include "marlin/ProcessorMgr.h"

// lcio includes
#include <IMPL/LCEventImpl.h>
#include <IMPL/LCCollectionVec.h>
#include <IMPL/TrackerRawDataImpl.h>
#include <UTIL/CellIDEncoder.h>
#include <UTIL/LCTime.h>
// #include <UTIL/LCTOOLS.h>

//root includes
#include <TROOT.h>
#include <TChain.h>
#include <TFile.h>

// system includes
#include <fstream>
#include <memory>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <cstdlib>
#include <sys/stat.h>

using namespace std;
using namespace marlin;
//using namespace CMSStrip;
using namespace eutelescope;


/*=====================================================================*/
CMSStripReader::CMSStripReader ():DataSourceProcessor  ("CMSStripReader") {
/*=====================================================================*/

  _description =
    "Reads data files and creates LCEvent with TrackerRawData collection.\n"
    "Make sure to not specify any LCIOInputFiles in the steering in order to read CMSPixel files.";

  registerProcessorParameter ("FilePath", "Input file path (RU files)",
                              _filePath, std::string ("."));
  registerProcessorParameter ("runNumber", "RunNumber",
                              _runNumber, static_cast < int >(01));
  registerProcessorParameter ("NoOfFEDs", "Number of FEDs",
                              _noOfFEDs, static_cast < int >(4));
  registerProcessorParameter ("NoOfFEDChannels", "Number of FED channels",
                              _noOfFEDChannels, static_cast < int >(8));
  //  registerProcessorParameter ("NoOfStrips", "Number of Strips per FED channel",
  //                              _noOfStrips, static_cast < int >(256));
  registerProcessorParameter ("ConnectionMap", "Associate modules to FED channels",
                              _connectionMap, std::string ("(0-0;0-1;0-2),(0-3;0-4;0-5),(0-6;0-7;1-0),(1-1;1-2;1-3),(1-4;1-5;1-6),(1-7;2-0;2-1),(2-2;2-3;2-4),(2-5;2-6;2-7),(3-0;3-1;3-2),(3-3;3-4;3-5),(3-6;3-7)"));


  registerOptionalParameter("DEBUG","Enable or disable DEBUG mode ",
                            _debugSwitch, static_cast< bool > ( 0 ) );
  registerOptionalParameter ("specialDUTs", "Module numbers of special DUTs",
                              _DUTs, std::string (""));
  registerOptionalParameter ("StripsInDUTRegions", "Special for MSSDs",
                              _noOfStripsInDUTRegion, static_cast < int >(32));
                              
}


/*=====================================================================
 CMSStripReader * CMSStripReader::newProcessor () {
=====================================================================

   return new CMSStripReader;
}*/

/*=====================================================================*/
 void CMSStripReader::init () {
/*=====================================================================*/
   _noOfStrips = 256;
    printParameters ();
}

/*=====================================================================*/
 void CMSStripReader::readDataSource (int Ntrig) 
   {
/*=====================================================================*/
 
    EUTelEventImpl *event = NULL;
    LCCollectionVec *rawData = NULL;
    TrackerRawDataImpl *rawMatrix[80];

    char filename0[256];
    char filename[256];

    
    // Set processor back to write the header:
    bool _isFirstEvent = true;
    int eventNumber = 0;

    // Initialize the trigger counter:
    int Ntriggers = 0;
    // Initialize DATA matrix
    int *DATA = 0;



    // Open File, check header, etc etc
    int index = 0;

    //sprintf(filename,"%s_%03d.root",_fileName.c_str(),index);
 /*   sprintf(filename0,"%s/RU%07d_%03d.root",_filePath.c_str(),_runNumber,index);

    TChain * tree = new TChain();
    streamlog_out ( MESSAGE ) << "Trying to add file " << filename0 << endl;

    struct stat FileStat;
    int ret = stat(filename0, &FileStat);
    streamlog_out ( DEBUG ) << "Return value: " << ret << endl;
*/
 /*   if(ret!=-1)
	tree->AddFile(filename0,TChain::kBigNumber,"TRU");
    else
      throw DataNotAvailableException("NO DATA FILE AVAILABLE");

    while(ret!=-1 && index < 100){
      index++;
      sprintf(filename,"%s/RU%07d_%03d.root",_filePath.c_str(),_runNumber,index);
      streamlog_out ( MESSAGE ) << "Trying to add file " << filename << endl;
      ret = stat(filename, &FileStat);
      streamlog_out ( MESSAGE ) << "return value is " << ret << endl;
      if(ret<0)
	streamlog_out ( MESSAGE ) << "Last file reached!" << endl;
      else
	tree->AddFile(filename,TChain::kBigNumber,"TRU");
      streamlog_out ( MESSAGE ) << "Total number of entries: " << tree->GetEntries() << endl;
    }
*/
    sprintf(filename0,"%s/RU%07d_%03d.root",_filePath.c_str(),_runNumber,index);
    struct stat FileStat;
    int ret = stat(filename0, &FileStat);
    streamlog_out ( DEBUG ) << "Return value: " << ret << endl;
   
    if(ret==-1)
      throw DataNotAvailableException("NO DATA FILE AVAILABLE");

    sprintf(filename,"%s/RU%07d_*.root/TRU",_filePath.c_str(),_runNumber);
    streamlog_out ( MESSAGE ) << "Trying to add files " << filename << endl;
    TChain * tree = new TChain();
    tree->Add (filename);

    streamlog_out ( MESSAGE ) << "Total number of entries: " << tree->GetEntries() << endl;

    int module = 0;
    int mux = 0;
    int fed, fed_ch;
    bool b_fed = true;
    int * sensor_id = new int[_noOfFEDs*_noOfFEDChannels]();
    int * section = new int[_noOfFEDs*_noOfFEDChannels]();

    for(int pos=0; pos<_connectionMap.size();pos++){
      if(_connectionMap.at(pos)=='('){
	mux=0;
	module++;
	b_fed=true;
      }
      else if ( _connectionMap.at(pos)==','){

      }
      else if (_connectionMap.at(pos)=='-'){
	b_fed=false;
      }
      else if (_connectionMap.at(pos)==';' || _connectionMap.at(pos)==')'){
	//sensor_id[fed*_noOfFEDChannels+fed_ch]=module;
 	//section[fed*_noOfFEDChannels+fed_ch]=mux;
	sensor_id[(module-1)*3+mux]=fed;
	section[(module-1)*3+mux]=fed_ch;
streamlog_out ( DEBUG ) << "Module: " << module << endl;
streamlog_out ( DEBUG ) << "mux: " << mux  << endl;
streamlog_out ( DEBUG ) << "fed: " << fed << endl;
streamlog_out ( DEBUG ) << "fed_ch: " << fed_ch  << endl;
	b_fed=true;
	mux++;
      }
      else{
	char number = _connectionMap.at(pos);
	if(b_fed){
	  if (number != 'n')
	      fed = atoi(&number);
	  else
	      fed = -1;
	  //sscanf(_connectionMap.at(pos),"%d",&fed);
	}
	else{
	  if (number != 'n')
	      fed_ch = atoi(&number);
          else
	      fed_ch = -1;
	  //sscanf(_connectionMap.at(pos),"%d",&fed_ch);
	}
      }
    }

    int * DUT = new int[10]();
    int nDUTs=0;
    char * ptr;

    if(_DUTs.size()>0){
      char * dutnumberstring = (char*)_DUTs.data();
      ptr = strtok(dutnumberstring,",");
      while(ptr != NULL){
	DUT[ nDUTs]=atoi(ptr);
	nDUTs++;
	ptr = strtok(NULL,",");
      }
    }
    streamlog_out ( DEBUG ) << "We have " << nDUTs << " special DUTs" << endl;

    for( int i=0; i<_noOfFEDs*_noOfFEDChannels;i++ ){
      streamlog_out ( MESSAGE ) << "sensor " << sensor_id[i] << " strip " <<section[i]*_noOfStrips << " at channel " << i << " (" << (i/_noOfFEDChannels) << "/"<< (i-(i/_noOfFEDChannels)*_noOfFEDChannels)<<")"<<endl;
      if(nDUTs>0)
	for(int j=0; j<nDUTs;j++)
	  if(sensor_id[i]==DUT[j]) streamlog_out ( MESSAGE ) << " *** this is a special DUT *** " << endl;
    }

    int **DataArray;
    DataArray = new int*[_noOfFEDChannels*_noOfStrips];
    char stringbuf[256];

    for(int fed=0; fed<_noOfFEDs;fed++){
      DataArray[fed] = new int[24+16*(128+12)];
      sprintf(stringbuf, "RU_%d", fed+1);
      tree->SetBranchAddress( (char*)stringbuf, (int*)&(DataArray[fed][0]));
    }

    int specialDUTsDone = 0;
    int channelcounter = 0;

    // Loop while we have input data
    while (true)
    {
        // Check if it's the first event:
        if(!_isFirstEvent) {
	  // Not first event, so write away last event data:
	  if(eventNumber%1000==0) streamlog_out ( MESSAGE ) << "write_data event" << eventNumber << endl;
	  event->addCollection (rawData, "rawdata");
	  ProcessorMgr::instance ()->processEvent (static_cast<LCEventImpl*> (event));
	  delete event;
	  streamlog_out ( DEBUG ) << "Event done" << endl;
        }
        else {
            // We are in the first event, so type BORE.
            auto_ptr<IMPL::LCRunHeaderImpl> lcHeader  ( new IMPL::LCRunHeaderImpl );
            auto_ptr<EUTelRunHeaderImpl>    runHeader ( new EUTelRunHeaderImpl (lcHeader.get()) );
            runHeader->addProcessor( type() );
            runHeader->lcRunHeader()->setDescription(" Events read from CMSStrip input file: " + string(filename0));
            runHeader->lcRunHeader()->setRunNumber (_runNumber);
            runHeader->setHeaderVersion (0.0001);
            runHeader->setDataType (EUTELESCOPE::CONVDATA);
            runHeader->setDateTime ();
            runHeader->addIntermediateFile (filename0);
            runHeader->addProcessor (_processorName);
            //runHeader->setNoOfDetector(_noOfFEDs*_noOfFEDChannels);
	    runHeader->setNoOfDetector(module);
            runHeader->setMinX(IntVec(_noOfFEDs*_noOfFEDChannels, 0));
	    //runHeader->setMaxX(IntVec(_noOfFEDs*_noOfFEDChannels, _noOfStrips - 1));
            runHeader->setMaxX(IntVec(_noOfFEDs*_noOfFEDChannels, _noOfStrips*3 - 1));
	    runHeader->setGeoID(1);

            runHeader->lcRunHeader()->setDetectorName("CMSStripTelescope");

            // process the run header
            ProcessorMgr::instance ()->processRunHeader ( static_cast<lcio::LCRunHeader*> ( lcHeader.release()) );
            _isFirstEvent = false;
	    streamlog_out ( MESSAGE ) << "Header done" << endl;
        }
        
        // Trigger counter:
        if(Ntriggers>=Ntrig) goto eor;
        Ntriggers++;
        
        // Start processing current event:     
        event = new EUTelEventImpl();
        event->setDetectorName("CMSStripTelescope");
        event->setEventType(kDE);
        LCTime * now = new LCTime();
        event->setTimeStamp(now->timeStamp());
        delete now;
        rawData = new LCCollectionVec(LCIO::TRACKERRAWDATA); //<---- Only for RAW data
	streamlog_out ( DEBUG ) << "New Raw Data Collection" << endl;

        eventNumber++;
        event->setRunNumber (_runNumber);
        event->setEventNumber (eventNumber);
	streamlog_out ( DEBUG ) << "Event number: " << eventNumber << endl;

	// Get new event from file
	if(tree->GetEntry(eventNumber)<1)
	  goto eor;

	// new DATA array to store info for one event and one FED channel (one MUX):
	// caution! the "()" is needed to initialize with zero!
	DATA = new int [_noOfStrips]();

	specialDUTsDone = 0;
	channelcounter = 0;

	//for(int fed=0; fed<_noOfFEDs;fed++){
	for(int mod=0; mod<module*3;mod++){
          int fed = sensor_id[mod];
          int ch = section[mod];
          short *sample=0;
	  streamlog_out ( DEBUG ) << "FED " << fed << endl;
	  streamlog_out ( DEBUG ) << "FED ch " << ch << endl;
	  if (fed != -1)
          {
	      sample = (short*)&DataArray[fed][23];
              streamlog_out ( DEBUG ) << "FED ID: " << DataArray[fed][21]<< endl;
	      streamlog_out ( DEBUG ) << "Event number: " << DataArray[fed][22]<< endl;
          }
	  else
          {
	      streamlog_out (DEBUG) << "FED -1, breaking..." << endl;
 	  }

	   

	  //for(int ch=0; ch<_noOfFEDChannels; ch++){
             //if (sensor_id[fed*_noOfFEDChannels + ch] != mod && section[fed*_noOfFEDChannels + ch] != muxchan) {streamlog_out ( DEBUG ) << "break " << fed << " " << ch  << " " << mod << " " << muxchan << endl;break; break;}

	    streamlog_out ( DEBUG ) << "FED channel " << ch << endl;

	    //if(sensor_id[fed*_noOfFEDChannels + ch]>0){

	      streamlog_out ( DEBUG ) << "Adding FED channel to module " << mod/3 << endl;

	      bool special = false;
	      if(nDUTs>0)
		for(int j=0; j<nDUTs;j++)
		  if(sensor_id[fed*_noOfFEDChannels + ch]==DUT[j]) special=true;

	      if(special){
		streamlog_out ( DEBUG ) << "Sorting special module!"<< endl;

		for(int i=0;i<_noOfStrips/_noOfStripsInDUTRegion;i++){ // loop over special regions
		  streamlog_out ( DEBUG ) << "Region " << i<< endl;

		  rawMatrix[channelcounter] = new TrackerRawDataImpl();
		  CellIDEncoder < TrackerRawDataImpl > idEncoder (EUTELESCOPE::MATRIXDEFAULTENCODING, rawData);
		  idEncoder["sensorID"] = module+section[fed*_noOfFEDChannels + ch]*(_noOfStrips/_noOfStripsInDUTRegion)+i+1;
		  //idEncoder["xMin"] = start_strip[fed*_noOfFEDChannels + ch]+i*(_noOfStripsInDUTRegion);
		  //idEncoder["xMax"] = start_strip[fed*_noOfFEDChannels + ch]+(i+1)*(_noOfStripsInDUTRegion);
		  idEncoder["xMin"] = 0;
		  idEncoder["xMax"] = _noOfStripsInDUTRegion-1;
		  idEncoder.setCellID (rawMatrix[channelcounter]);
		  streamlog_out ( DEBUG ) << idEncoder["sensorID"] << " " << idEncoder["xMin"] << " " << idEncoder["xMax"] << endl;
		  if(eventNumber==1)
		    streamlog_out ( MESSAGE ) << "Special DUT module " << sensor_id[fed*_noOfFEDChannels + ch] << " xMin:" << section[fed*_noOfFEDChannels + ch]*_noOfStrips+i*(_noOfStripsInDUTRegion) << " xMax" << section[fed*_noOfFEDChannels + ch]*_noOfStrips+(i+1)*(_noOfStripsInDUTRegion)-1 << " -> sensor_id " << idEncoder["sensorID"] << " xMin:" << idEncoder["xMin"] << " xMax" << idEncoder["xMax"] << endl;

		  //Loop over all strips of one FED channel
		  if((i+1)*_noOfStripsInDUTRegion<128){
		    for(int pin=0; pin<128;pin++){
		      int phys_strip = 32*(pin%4)+8*(pin/4)-31*(pin/16);
		      DATA[phys_strip] = sample[(pin+12)*16+0+ch];
		      //streamlog_out ( DEBUG ) << "Raw Strip chip 1-" << pin << ": " << sample[(pin+12)*16+0+ch] << endl;
		    }
		  }
		  else{
		    for(int pin=0; pin<128;pin++){
		      int phys_strip = 32*(pin%4)+8*(pin/4)-31*(pin/16);
		      DATA[phys_strip+128] = sample[(pin+12)*16+8+ch];
		      //streamlog_out ( DEBUG ) << "Raw Strip chip 2-" << pin << ": " << sample[(pin+12)*16+8+ch] << endl;
		    }
		  }
		  for(int pin=i*_noOfStripsInDUTRegion; pin<(i+1)*_noOfStripsInDUTRegion;pin++){
		    rawMatrix[channelcounter]->adcValues().push_back (DATA[pin]);
		    streamlog_out ( DEBUG ) << "Strip " << pin << ": " << DATA[pin] << endl;
		  }
		  channelcounter++;
		}
		specialDUTsDone++;
		special=false;
	      }
	      else{
		streamlog_out ( DEBUG ) << "mux " << mux << endl;
                if (mod%3==0)
                {
		    streamlog_out ( DEBUG ) << "Create new rawMatrix " << channelcounter << endl;
                    rawMatrix[channelcounter] = new TrackerRawDataImpl();
                }
	        CellIDEncoder < TrackerRawDataImpl > idEncoder (EUTELESCOPE::MATRIXDEFAULTENCODING, rawData);
	        //idEncoder["sensorID"] = sensor_id[fed*_noOfFEDChannels + ch];
	        //idEncoder["xMin"] = section[fed*_noOfFEDChannels + ch]*_noOfStrips;
	        //idEncoder["xMax"] = (section[fed*_noOfFEDChannels + ch]+1)*_noOfStrips-1;
                idEncoder["sensorID"] = mod/3;
	        idEncoder["xMin"] = 0;//(mod%3)*256;
	        idEncoder["xMax"] = 767;//((mod%3)+1)*256-1;
	        idEncoder.setCellID (rawMatrix[channelcounter]);
	        streamlog_out ( DEBUG ) << idEncoder["sensorID"] << " " << idEncoder["xMin"] << " " << idEncoder["xMax"] << endl;
		
		if (sensor_id[mod] != -1)
                {
			//Loop over all strips of one FED channel	    
			for(int pin=0; pin<128;pin++){
			  int phys_strip = 32*(pin%4)+8*(pin/4)-31*(pin/16);
			  DATA[phys_strip] = sample[(pin+12)*16+0+ch];
			  //streamlog_out ( DEBUG ) << "Raw Strip chip 1-" << pin << ": " << sample[(pin+12)*16+0+ch] << endl;
			}
			for(int pin=0; pin<128;pin++){
			  int phys_strip = 32*(pin%4)+8*(pin/4)-31*(pin/16);
			  DATA[phys_strip+128] = sample[(pin+12)*16+8+ch];
			  //streamlog_out ( DEBUG ) << "Raw Strip chip 2-" << pin << ": " << sample[(pin+12)*16+8+ch] << endl;
			}
			for(int pin=0; pin<_noOfStrips;pin++){
			      rawMatrix[channelcounter]->adcValues().push_back (DATA[pin]);
			      //streamlog_out ( DEBUG ) << "Strip " << pin << ": " << DATA[pin] << endl;
			}
                }
		else
		{
			idEncoder["xMax"] = (mod)%3*256-1;
			idEncoder.setCellID (rawMatrix[channelcounter]);
			streamlog_out (DEBUG) << "setting xMax to " << (mod)%3*256-1 << endl;
		}
		
		if (mod%3==2) channelcounter++;
	      }
	    //}
	  //}
	} // end of FED loop

        for (int i=0;i<channelcounter;i++) {
	  //streamlog_out ( DEBUG ) << "push back rawMatrix[" << i << "]" << endl;
            rawData->push_back (rawMatrix[i]);  
        }
	
    }; // end of while (true)

    // Jump here on End Of Run:
    eor:
    // Write last event with type EORE
    event = new EUTelEventImpl;
    event->setDetectorName("CMSStripTelescope");
    LCTime * now = new LCTime;
    event->setTimeStamp(now->timeStamp());
    delete now;
    event->setRunNumber (_runNumber);
    event->setEventNumber (eventNumber++);
    event->setEventType(kEORE);
    ProcessorMgr::instance ()->processEvent (static_cast<LCEventImpl*> (event));
    delete event;
    // free memory of DATA:             
    delete DATA;
    delete DUT;
 }


/*=====================================================================*/

 void CMSStripReader::end () {
   message<MESSAGE> ("Successfully finished") ;
 }

/*=====================================================================*/


