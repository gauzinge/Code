#include "TelescopeTrackExporter.h"
#include <iostream>
#include <string>

#include <EVENT/LCCollection.h>
#include <EVENT/MCParticle.h>

// ----- include for verbosity dependend logging ---------
#include "marlin/VerbosityLevels.h"

#ifdef MARLIN_USE_AIDA
#include <marlin/AIDAProcessor.h>
#include <AIDA/IHistogramFactory.h>
#include <AIDA/ICloud1D.h>
//#include <AIDA/IHistogram1D.h>
#endif // MARLIN_USE_AIDA

// gear includes <.h>
#include <gear/GearMgr.h>
#include <gear/SiPlanesParameters.h>

// eutelescope includes ".h"
#include "EUTelAlignmentConstant.h"
#include "EUTELESCOPE.h"
#include "EUTelEventImpl.h"
#include "EUTelRunHeaderImpl.h"
#include "EUTelHistogramManager.h"
#include "EUTelExceptions.h"
#include "EUTelAPIXSparsePixel.h"
#include "EUTelSparseDataImpl.h"
#include "EUTelAPIXSparseClusterImpl.h"

// marlin includes ".h"
#include "marlin/Processor.h"
#include "marlin/Exceptions.h"
#include "marlin/Global.h"

// lcio includes <.h>
#include <UTIL/CellIDEncoder.h>
#include <UTIL/CellIDDecoder.h>
#include <EVENT/LCCollection.h>
#include <EVENT/LCEvent.h>
#include <IMPL/LCCollectionVec.h>
#include <IMPL/TrackerHitImpl.h>
#include <IMPL/TrackImpl.h>
#include <IMPL/TrackerDataImpl.h>
#include <IMPL/LCFlagImpl.h>
#include <Exceptions.h>

// ROOT includes:
#include "TVector3.h"
#include "TGraph.h"
#include "TF1.h"


using namespace lcio ;
using namespace marlin ;

using namespace std;
using namespace eutelescope;
using namespace gear;



TelescopeTrackExporter aTelescopeTrackExporter ;


TelescopeTrackExporter::TelescopeTrackExporter() : Processor("TelescopeTrackExporter") {

    // modify processor description
    _description = "Telescope Track Exporter exports Telescope Tracks (Projections to DUT Planes) in a ROOT Tree" ;

    
    registerInputCollection (LCIO::TRACK, "InputTrackCollectionName",
                             "The name of the input Track collection",
                             _inputTrackCollectionName, string ("Track"));
      
    registerProcessorParameter("Root File","This is the name of the file that will contain the TTrees with DUT Hits and Telescope Tracks (add .root)",
                               _rootFile, static_cast< string > ( "TBData.root" ) );



//  _siPlanesParameters  = const_cast<SiPlanesParameters* > (&(Global::GEAR->getSiPlanesParameters()));
//  _siPlanesLayerLayout = const_cast<SiPlanesLayerLayout*> ( &(_siPlanesParameters->getSiPlanesLayerLayout() ));
}



void TelescopeTrackExporter::init() { 
    //Definitions
    xSlope=0, xIntercept=0;
    ySlope=0, yIntercept=0;
    evtno=0;
    evtwotrack=0;
    evtwtrack=0;

    streamlog_out(DEBUG) << "   init called  " << std::endl ;
    file=new TFile(_rootFile.c_str(), "RECREATE");
    if (!file){
        streamlog_out( ERROR4 ) << "Can not create Root file!" << std::endl;
        throw UnknownDataTypeException("SORRY FOR QUITTING!");
    } else if (file->IsZombie()) {
        streamlog_out( ERROR4 ) << "Error opening Root file!" << std::endl;
         throw UnknownDataTypeException("SORRY FOR QUITTING!");
    } else {
        streamlog_out ( MESSAGE ) << "TFile successfully created!" << std::endl;
        TelescopeTrack = new TTree ("TelescopeTrack", "TTree with Telescope Tracks in Telescope Frame of Reference");
        //TELESCOPE TRACK
        TelescopeTrack->Branch("EventNo", &evtno,"EventNo/I");
        TelescopeTrack->Branch("xSlope",&xSlope,"xSlope/D");
        TelescopeTrack->Branch("ySlope",&ySlope,"ySlope/D");
        TelescopeTrack->Branch("xIntercept",&xIntercept,"xIntercept/D");
        TelescopeTrack->Branch("yIntercept",&yIntercept,"yIntercept/D");

    }
    
    // usually a good idea to
    printParameters() ;
    
}


void TelescopeTrackExporter::processRunHeader( LCRunHeader* run) { 
    
    auto_ptr<EUTelRunHeaderImpl> runHeader ( new EUTelRunHeaderImpl( run ));
    runHeader->addProcessor( type() );

} 



void TelescopeTrackExporter::processEvent( LCEvent * event ) { 

    
    // this gets called for every event 
    // usually the working horse ...
    //-- note: this will not be printed if compiled w/o MARLINDEBUG=1 !

    streamlog_out(DEBUG) << "   processing event: " << event->getEventNumber() 
        << "   in run:  " << event->getRunNumber() << std::endl ;


  EUTelEventImpl * evt = static_cast<EUTelEventImpl*> (event);


  if ( evt->getEventType() == kEORE ) 
  {
    streamlog_out ( DEBUG4 ) << "EORE found: nothing else to do." << endl;
    return;
  }
  else if ( evt->getEventType() == kUNKNOWN ) 
  {
    streamlog_out ( WARNING2 ) << "Event number " << evt->getEventNumber() << " in run " << evt->getRunNumber()
                               << " is of unknown type. Continue considering it as a normal Data Event." << endl;
  }
    
    //TEMPORARY
    TGraph* grx = new TGraph();
    TGraph* gry = new TGraph();
    
       
// Here the party starts
    if ((file) && (!file->IsZombie())) {
        
        //Telescope Tracks Loop
        try 
        { //Make common try/catch??
            if ((evt->getEventNumber()) % 1000 ==0)
            { 
                streamlog_out( MESSAGE ) << evt->getEventNumber() << " Events processed!" << std::endl;

            }
                       
            LCCollection* inputTrackCollection         = dynamic_cast < LCCollection * > (evt->getCollection(_inputTrackCollectionName));

            for ( size_t iTrack = 0; iTrack < static_cast<size_t>(inputTrackCollection->getNumberOfElements()); iTrack++ ) //loops through tracks 
                
            {
                TrackImpl * track = dynamic_cast<TrackImpl*> ( inputTrackCollection->getElementAt(iTrack) );
                TrackerHitVec hitvec = track->getTrackerHits(); //number of hit Planes
                
                for ( size_t iHit = 0; iHit < hitvec.size()  ; ++iHit ) //loops through hits in track
                {
                    
                    
                    TrackerHitImpl * hit;
                    if ( (hit = dynamic_cast<TrackerHitImpl*> ( hitvec[ iHit ] )) != 0x0 ) 
                    {
                        // show only hit resulting from fit (type == 32)
                        if ( hit->getType() == 32 ) 
                        {
                            double xHit = static_cast< float > ( hit->getPosition()[0] );
                            double yHit = static_cast< float > ( hit->getPosition()[1] );
                            double zHit = static_cast< float > ( hit->getPosition()[2] );
                            
//                            if ( zHit != zPos ) //zPos is DUT zPos and we do not want that in our reference Tracks Collection
//                            {
                                //Put Hits in graph grx and gry
                                grx->SetPoint(grx->GetN(),zHit, xHit); // x versus z
                                gry->SetPoint(gry->GetN(),zHit, yHit); // y versus z
//                            }
                            
                        }
//                        else streamlog_out (MESSAGE) << "x " << hit->getPosition()[0] << " y " <<hit->getPosition()[1] << " z " << hit->getPosition()[2] << " type " << hit->getType() << std::endl;
                    }
                } //end of hits in track loop
                
                //do lin. Fit of Hits in Track and interpolate at DUT zPOS
                
                grx->Fit("pol1","Q");
                gry->Fit("pol1","Q");
                
                TF1* xfit = grx->GetFunction("pol1");
                TF1* yfit = gry->GetFunction("pol1");
                //now the fitted lin. Function is in xfit and yfit
                xSlope = xfit->GetParameter(1);
                xIntercept = xfit->GetParameter(0);
                ySlope = yfit->GetParameter(1);
                yIntercept = yfit->GetParameter(0);
                evtno = evt->getEventNumber();

//                streamlog_out (MESSAGE) << "Hit coordinates in DUT Plane (z= " << zPos <<" ) are " << grx->Eval(zPos) << " " << gry->Eval(zPos) << " Slope / Intercept x,y " << xSlope << " " << xIntercept << " " << ySlope << " " << yIntercept << std::endl;
                
                TelescopeTrack->Fill(); //Fill Tree
                evtwtrack++;
            } //end of tracks loop
            file->Flush();

        } //end of try
        catch(DataNotAvailableException& e) 
        {
//            streamlog_out  ( WARNING2 ) <<  "No input Track collection found on event " << event->getEventNumber()
//            << " in run " << event->getRunNumber() << endl;
            evtwotrack++;
        }
        
    }
        _nEvt ++;
        delete grx;
        delete gry;
        
}



void TelescopeTrackExporter::check( LCEvent * evt ) { 
    // nothing to check here - could be used to fill checkplots in reconstruction processor
}


void TelescopeTrackExporter::end(){ 
    if ((file) && (!file->IsZombie()))
    {
        
        file->Write();
        file->Close();
        streamlog_out (MESSAGE) << "TFile Successfully written and closed!" << std::endl;
        streamlog_out (MESSAGE) << evtwtrack << " Events w tracks found!" << std::endl;
        streamlog_out (MESSAGE) << evtwotrack << " Events w/o tracks found!" << std::endl;
        
    }
   
//    delete TelescopeTrack;
    
    streamlog_out (MESSAGE) << "TelescopeTrackExporter::end()  " << name() 
    << " processed " << _nEvt << " events." << std::endl ;
    
}

