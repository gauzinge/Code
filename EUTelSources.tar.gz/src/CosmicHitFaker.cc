#include "CosmicHitFaker.h"
#include <iostream>
#include <string>

#include <EVENT/LCCollection.h>
#include <EVENT/MCParticle.h>

// ----- include for verbosity dependend logging ---------
#include "marlin/VerbosityLevels.h"

#ifdef MARLIN_USE_AIDA
#include <marlin/AIDAProcessor.h>
#include <AIDA/IHistogramFactory.h>
#include <AIDA/ICloud1D.h>
//#include <AIDA/IHistogram1D.h>
#endif // MARLIN_USE_AIDA

// gear includes <.h>
#include <gear/GearMgr.h>
#include <gear/SiPlanesParameters.h>

// eutelescope includes ".h"
#include "EUTelAlignmentConstant.h"
#include "EUTELESCOPE.h"
#include "EUTelEventImpl.h"
#include "EUTelRunHeaderImpl.h"
#include "EUTelHistogramManager.h"
#include "EUTelExceptions.h"
#include "EUTelAPIXSparsePixel.h"
#include "EUTelSparseDataImpl.h"
#include "EUTelAPIXSparseClusterImpl.h"

// marlin includes ".h"
#include "marlin/Processor.h"
#include "marlin/Exceptions.h"
#include "marlin/Global.h"

// lcio includes <.h>
#include <UTIL/CellIDEncoder.h>
#include <UTIL/CellIDDecoder.h>
#include <EVENT/LCCollection.h>
#include <EVENT/LCEvent.h>
#include <IMPL/LCCollectionVec.h>
#include <IMPL/TrackerHitImpl.h>
#include <IMPL/TrackImpl.h>
#include <IMPL/TrackerDataImpl.h>
#include <IMPL/LCFlagImpl.h>
#include <Exceptions.h>

// ROOT includes:
#include "TVector3.h"
#include "TGraph.h"
#include "TF1.h"


using namespace lcio ;
using namespace marlin ;

using namespace std;
using namespace eutelescope;
using namespace gear;


CosmicHitFaker aCosmicHitFaker ;


CosmicHitFaker::CosmicHitFaker() : Processor("CosmicHitFaker") {

    // modify processor description
    _description = "CosmicHitFaker does whatever it does ..." ;


  // first of all we need to register the input collection
  registerInputCollection (LCIO::TRACKERHIT, "InputHitCollectionName",
                           "The name of the input hit collection",
                           _inputHitCollectionName, string ("hit"));

  registerOutputCollection (LCIO::TRACKERHIT, "OutputHitCollectionName",
                            "The name of the output hit collection",
                            _outputHitCollectionName, string("correctedHit"));


}



void CosmicHitFaker::init() { 

    streamlog_out(DEBUG) << "   init called  " << std::endl ;

    // usually a good idea to
    printParameters() ;

    streamlog_out (MESSAGE4) << "Getting Geometry from GEAR file!" << std::endl;
    streamlog_out (MESSAGE4) << "For the moment the info what sensor measures what direction is hardcoded." << std::endl;

//    _siPlanesParameters  = const_cast<SiPlanesParameters* > (&(Global::GEAR->getSiPlanesParameters()));
//     _siPlanesLayerLayout = const_cast<SiPlanesLayerLayout*> ( &(_siPlanesParameters->getSiPlanesLayerLayout() ));
//    _planePosition   = new double[8];
//    
//    for(int ipl=0; ipl <  _siPlanesLayerLayout->getNLayers(); ipl++)
//    {
//        _planePosition[ipl]=_siPlanesLayerLayout->getLayerPositionZ(ipl);
//    }

}


void CosmicHitFaker::processRunHeader( LCRunHeader* run) { 

} 



void CosmicHitFaker::processEvent( LCEvent * event ) { 


    // this gets called for every event 
    // usually the working horse ...




    //-- note: this will not be printed if compiled w/o MARLINDEBUG=1 !

    streamlog_out(DEBUG) << "   processing event: " << event->getEventNumber() 
        << "   in run:  " << event->getRunNumber() << std::endl ;


  EUTelEventImpl * evt = static_cast<EUTelEventImpl*> (event);


  if ( evt->getEventType() == kEORE ) 
  {
    streamlog_out ( DEBUG4 ) << "EORE found: nothing else to do." << endl;
    return;
  }
  else if ( evt->getEventType() == kUNKNOWN ) 
  {
    streamlog_out ( WARNING2 ) << "Event number " << evt->getEventNumber() << " in run " << evt->getRunNumber()
                               << " is of unknown type. Continue considering it as a normal Data Event." << endl;
  }

  TGraph* grx = new TGraph();
  TGraph* gry = new TGraph();

  try 
  {

    LCCollectionVec * inputCollectionVec         = dynamic_cast < LCCollectionVec * > (evt->getCollection(_inputHitCollectionName));

    LCCollectionVec * outputCollectionVec = new LCCollectionVec(LCIO::TRACKERHIT);
    
    for (size_t iHit = 0; iHit < inputCollectionVec->size(); iHit++) {
      TrackerHitImpl   * inputHit   = dynamic_cast< TrackerHitImpl * >  ( inputCollectionVec->getElementAt( iHit ) ) ;
 
      // copy the input to the output, at least for the common part
      TrackerHitImpl   * outputHit  = new TrackerHitImpl;
      outputHit->setType( inputHit->getType() );
      outputHit->rawHits() = inputHit->getRawHits();


      double * inputPosition      = const_cast< double * > ( inputHit->getPosition() ) ;

      streamlog_out (DEBUG) << "new hit x: " << inputPosition[0] << " y: " << inputPosition[1] << " z: " << inputPosition[2] <<endl; 
      if (fabs(inputPosition[0])<1e-5) //rotated sensor
//        if (fabs(inputPosition[2])-_planePosition[1] < 5 || fabs(inputPosition[2])-_planePosition[3] < 5 || fabs(inputPosition[2])-_planePosition[4] < 5 || fabs(inputPosition[2])-_planePosition[6] < 5) //rotated sensor

      {
	 gry->SetPoint(gry->GetN(),inputPosition[2], inputPosition[1]);
	 streamlog_out (DEBUG) << "gry set point z:" << inputPosition[2] << " " << inputPosition[1] << endl; 
      }
      else if (fabs(inputPosition[1])<1e-5) //not rotated sensor
//        else if (fabs(inputPosition[2])-_planePosition[0] < 5 || fabs(inputPosition[2])-_planePosition[2] < 5 || fabs(inputPosition[2])-_planePosition[5] < 5 || fabs(inputPosition[2])-_planePosition[7] < 5) // not rotated sensor
      {
	 grx->SetPoint(grx->GetN(),inputPosition[2], inputPosition[0]);
	 streamlog_out (DEBUG) << "grx set point z:" << inputPosition[2] << " " << inputPosition[0] << endl; 
      }

      
    }

    if (grx->GetN() > 3 && gry->GetN() > 3)
    {
	    grx->Fit("pol1","Q");
	    gry->Fit("pol1","Q");
  

	    for (size_t iHit = 0; iHit < inputCollectionVec->size(); iHit++) {
		TrackerHitImpl   * inputHit   = dynamic_cast< TrackerHitImpl * >  ( inputCollectionVec->getElementAt( iHit ) ) ;
	 
	      // copy the input to the output, at least for the common part
	      TrackerHitImpl   * outputHit  = new TrackerHitImpl;
	      outputHit->setType( inputHit->getType() );
	      outputHit->rawHits() = inputHit->getRawHits();


	      double * inputPosition      = const_cast< double * > ( inputHit->getPosition() ) ;
            double   outputPosition[3]={0,0,0};
	      if (fabs(inputPosition[0])<1e-5) //rotated sensor
//            if (fabs(inputPosition[2])-_planePosition[1] < 5 || fabs(inputPosition[2])-_planePosition[3] < 5 || fabs(inputPosition[2])-_planePosition[4] < 5 || fabs(inputPosition[2])-_planePosition[6] < 5) //rotated sensor
	      {
	      	outputPosition[0] = grx->Eval(inputPosition[2]);
		outputPosition[1] = inputPosition[1];
		outputPosition[2] = inputPosition[2];
	      }
	      else if (fabs(inputPosition[1])<1e-5) //not rotated sensor
//            else if (fabs(inputPosition[2])-_planePosition[0] < 5 || fabs(inputPosition[2])-_planePosition[2] < 5 || fabs(inputPosition[2])-_planePosition[5] < 5 || fabs(inputPosition[2])-_planePosition[7] < 5) // not rotated sensor
	      {
	      	outputPosition[0] = inputPosition[0];
		outputPosition[1] = gry->Eval(inputPosition[2]);
		outputPosition[2] = inputPosition[2];
	      }
//          else streamlog_out (MESSAGE4) << "Something weird is happening " << std::endl;
              streamlog_out (MESSAGE4) << "old hit coordinates x:" << inputPosition[0] << " y: " << inputPosition[1] << " z: " << inputPosition[2]<< endl;
	      streamlog_out (MESSAGE4) << "new hit coordinates x:" << outputPosition[0] << " y: " << outputPosition[1] << " z: " << outputPosition[2]<< endl << endl;


	      outputHit->setPosition( outputPosition ) ;
	      outputCollectionVec->push_back( outputHit );
	    }
    }
    else
    {
	streamlog_out (DEBUG) << "Hits can not be converted, skipping event!" << endl;
    }

    delete grx; delete gry;

    evt->addCollection( outputCollectionVec, _outputHitCollectionName );

  }
  catch (DataNotAvailableException& e) {
    streamlog_out  ( WARNING2 ) <<  "No input collection found on event " << event->getEventNumber()
                                << " in run " << event->getRunNumber() << endl;
  }
  _nEvt ++ ;




}



void CosmicHitFaker::check( LCEvent * evt ) { 
    // nothing to check here - could be used to fill checkplots in reconstruction processor
}


void CosmicHitFaker::end(){ 

    //   std::cout << "CosmicHitFaker::end()  " << name() 
    // 	    << " processed " << _nEvt << " events in " << _nRun << " runs "
    // 	    << std::endl ;

}

