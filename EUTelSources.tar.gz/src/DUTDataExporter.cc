#include "DUTDataExporter.h"
#include <iostream>
#include <string>

#include <EVENT/LCCollection.h>
#include <EVENT/MCParticle.h>
#include "EUTelExceptions.h"

// ----- include for verbosity dependend logging ---------
#include "marlin/VerbosityLevels.h"

#ifdef MARLIN_USE_AIDA
#include <marlin/AIDAProcessor.h>
#include <AIDA/IHistogramFactory.h>
#include <AIDA/ICloud1D.h>
//#include <AIDA/IHistogram1D.h>
#endif // MARLIN_USE_AIDA

// gear includes <.h>
#include <gear/GearMgr.h>
#include <gear/SiPlanesParameters.h>

// eutelescope includes ".h"
#include "EUTelAlignmentConstant.h"
#include "EUTELESCOPE.h"
#include "EUTelEventImpl.h"
#include "EUTelRunHeaderImpl.h"
#include "EUTelHistogramManager.h"
#include "EUTelExceptions.h"
#include "EUTelAPIXSparsePixel.h"
#include "EUTelSparseDataImpl.h"
#include "EUTelAPIXSparseClusterImpl.h"

//Cluster includes ".h"
#include "EUTelVirtualCluster.h"
#include "EUTelFFClusterImpl.h"
#include "EUTelDFFClusterImpl.h"
#include "EUTelBrickedClusterImpl.h"
#include "EUTelSparseClusterImpl.h"
#include "EUTelSparseCluster2Impl.h"

// marlin includes ".h"
#include "marlin/Processor.h"
#include "marlin/Exceptions.h"
#include "marlin/Global.h"

// lcio includes <.h>
#include <UTIL/CellIDDecoder.h>
#include <EVENT/LCCollection.h>
#include <EVENT/LCEvent.h>
#include <IMPL/LCCollectionVec.h>
#include <IMPL/TrackerHitImpl.h>
#include <IMPL/TrackerPulseImpl.h>
#include <IMPL/TrackerRawDataImpl.h>

#include <IMPL/TrackImpl.h>
#include <IMPL/TrackerDataImpl.h>
#include <IMPL/LCFlagImpl.h>
#include <Exceptions.h>

// lcio includes <.h>
#include <IMPL/TrackerRawDataImpl.h>
#include <IMPL/TrackerDataImpl.h>
#include <IMPL/LCCollectionVec.h>
#include <UTIL/CellIDDecoder.h>
#include <UTIL/CellIDEncoder.h>

// system includes 
#include <sstream>
#include <iostream>
#include <iomanip>
#include <memory>

//// ROOT includes:
//#include "TVector3.h"
//#include "TGraph.h"
//#include "TFile.h"
//#include "TTree.h"
//#include "TF1.h"
//#include "TBranch.h"


using namespace lcio ;
using namespace marlin ;

using namespace std;
using namespace eutelescope;
using namespace gear;


//Definitions
//double DUTxPos, DUTzPos;
//int DUTevtno;
//float clu_ChargeLeading;
//float clu_Charge[10];
//TFile* Hitfile=NULL;
//TTree* DUTHit=NULL;
//TBranch* EventNo;
//TBranch* xPos;
//TBranch* zPos;
//TBranch* ChargeLeading;
//TBranch *Charge;


DUTDataExporter aDUTDataExporter ;

DUTDataExporter::DUTDataExporter() : Processor("DUTDataExporter") {
    
    


    // modify processor description
    _description = "Telescope Track Exporter exports Telescope Tracks (Projections to DUT Planes) in a ROOT Tree" ;


    // first of all we need to register the input collections
    
    

    
    registerInputCollection (LCIO::TRACKERRAWDATA, "InputRawDataCollectionName",
                             "The name of the input RawData collection (really raw)",
                             _inputRawDataCollectionName, string ("rawdata"));
    
    
    registerInputCollection (LCIO::TRACKERDATA, "PedestalCollectionName",
                             "Pedestal from the condition file",
                             _pedestalCollectionName, string ("pedestal"));
    
    registerInputCollection (LCIO::TRACKERDATA, "NoiseCollectionName",
                             "Noise from the condition file",
                             _noiseCollectionName, string("noise"));
    
    registerProcessorParameter("DUT ID","This is the ID of the DUT whose data will be written in the file.",
                               _DUT_ID, static_cast< int > ( 0 ) );

    registerProcessorParameter("Root File","This is the name of the file that will contain the TTrees with DUT Hits and Telescope Tracks (add .root)",
                               _rootFile, static_cast< string > ( "TBData.root" ) );
    
}



void DUTDataExporter::init() { 

    
    
    streamlog_out(DEBUG) << "   init called  " << std::endl ;
    Hitfile=new TFile(_rootFile.c_str(), "RECREATE");
    if (!Hitfile){
        streamlog_out( ERROR4 ) << "Can not create Root file!" << std::endl;
        throw UnknownDataTypeException("SORRY FOR QUITTING!");
    } else if (Hitfile->IsZombie()) {
        streamlog_out( ERROR4 ) << "Error opening Root file!" << std::endl;
         throw UnknownDataTypeException("SORRY FOR QUITTING!");
    } else {
        streamlog_out ( MESSAGE ) << "TFile successfully created!" << std::endl;
        DUTData = new TTree ("DUTData", "TTree with  DUT Raw Data e");
        DUTPedeNoise = new TTree ("DUTPedeNoise", "TTree with  DUT Pedestals /Noise");

        //DUT DATA
        EventNo = DUTData->Branch("EventNo", &DUTevtno, "EventNo/I");
        //Raw Data Vector
        adc_values = DUTData->Branch("ADCValues", DUTadc_values, "ADCValues[390]/I");
        
        DUTzPosition = DUTData->Branch("DUTzPosition", &zPosition, "DUTzPosition/D" );
        
        //DUT PEDE & NOISE
        //Pedestal Vector
        pedestal_values = DUTPedeNoise->Branch("PedestalValues", DUTpedestal_values, "PedestalValues[390]/F" );
        noise_values = DUTPedeNoise->Branch("NoiseValues", DUTnoise_values, "NoiseValues[390]/F");
    }
    
#ifndef USE_GEAR
    
    streamlog_out ( ERROR4 ) <<  "Marlin was not built with GEAR support." << endl
    <<  "You need to install GEAR and recompile Marlin with -DUSE_GEAR before continue." << endl;
    exit(-1);
    
#else
    
    // check if the GEAR manager pointer is not null!
    if ( Global::GEAR == 0x0 ) {
        streamlog_out ( ERROR4 ) <<  "The GearMgr is not available, for an unknown reason." << endl;
        exit(-1);
    }
    
    _siPlanesParameters  = const_cast<SiPlanesParameters* > (&(Global::GEAR->getSiPlanesParameters()));
    _siPlanesLayerLayout = const_cast<SiPlanesLayerLayout*> ( &(_siPlanesParameters->getSiPlanesLayerLayout() ));
    
    
#endif

    
    // usually a good idea to
    printParameters() ;
}


void DUTDataExporter::processRunHeader( LCRunHeader* run) { 
    
    auto_ptr<EUTelRunHeaderImpl> runHeader ( new EUTelRunHeaderImpl( run ));
    runHeader->addProcessor( type() );

} 


void DUTDataExporter::initializeGeometry(LCEvent * event) throw ( marlin::SkipEventException ) {
    
    // now I need the _ancillaryIndexMap. For this I need to take the
    // pedestal input collection
    try {
        LCCollectionVec * pedestalCol = dynamic_cast< LCCollectionVec * > ( event->getCollection( _pedestalCollectionName ) );
        CellIDDecoder< TrackerDataImpl > pedestalDecoder( pedestalCol ) ;
        for ( size_t iDetector = 0; iDetector < pedestalCol->size(); ++iDetector ) {
            TrackerDataImpl * pedestal = dynamic_cast< TrackerDataImpl * > ( pedestalCol->getElementAt( iDetector ) ) ;
            
            int sensorID = pedestalDecoder( pedestal )["sensorID"];
            
            _ancillaryIndexMap.insert( make_pair( sensorID, iDetector ) );
            
            unsigned int noOfPixel = 384;
            
            _noOfPixelMap.insert( make_pair( sensorID, noOfPixel ) );
            
            unsigned int noOfPixelPerRow = 384;
            _noOfPixelPerRowMap.insert( make_pair ( sensorID, noOfPixelPerRow ));
            
            unsigned int noOfRow =  1;
            _noOfRowMap.insert( make_pair( sensorID, noOfRow ) );
            
        }
    } catch ( lcio::DataNotAvailableException ) {
        streamlog_out( WARNING2 ) << "Unable to initialize the geometry with the current event. Trying with the next one" << endl;
        _isGeometryReady = false;
    throw SkipEventException( this );

    }
    
    _isGeometryReady = true;
}



void DUTDataExporter::processEvent( LCEvent * event ) { 
    
    if ( !_isGeometryReady ) {
        initializeGeometry( event ) ;
    }
    
    streamlog_out(DEBUG) << "   processing event: " << event->getEventNumber() 
    << "   in run:  " << event->getRunNumber() << std::endl ;
    
    
    EUTelEventImpl * evt = static_cast<EUTelEventImpl*> (event);
    
    
    if ( evt->getEventType() == kEORE ) 
    {
        streamlog_out ( DEBUG4 ) << "EORE found: nothing else to do." << endl;
        return;
    }
    else if ( evt->getEventType() == kUNKNOWN ) 
    {
        streamlog_out ( WARNING2 ) << "Event number " << evt->getEventNumber() << " in run " << evt->getRunNumber()
        << " is of unknown type. Continue considering it as a normal Data Event." << endl;
    }
    
    
    // Here the party starts
    if ((Hitfile) && (!Hitfile->IsZombie())) {
        try
        {
            
            //Raw Data
            LCCollectionVec * inputRawDataCollectionVec         = dynamic_cast < LCCollectionVec * > (evt->getCollection(_inputRawDataCollectionName));
            CellIDDecoder<TrackerRawDataImpl> cellDecoder( inputRawDataCollectionVec );
            
            //Pedestal
            LCCollectionVec * pedestalCollectionVec = dynamic_cast < LCCollectionVec * > (evt->getCollection(_pedestalCollectionName));
            
            //Noise
            LCCollectionVec * noiseCollectionVec    = dynamic_cast < LCCollectionVec * > (evt->getCollection(_noiseCollectionName));
            
            
            for (unsigned int iDetector = 0; iDetector < inputRawDataCollectionVec->size(); iDetector++) {
                
                
                //Raw Data
                TrackerRawDataImpl   * inputRawData   = dynamic_cast< TrackerRawDataImpl * >  ( inputRawDataCollectionVec->getElementAt( iDetector ));
                int sensorID = cellDecoder(inputRawData)["sensorID"];
                
                //Pedestals
                TrackerDataImpl    * pedestal = dynamic_cast < TrackerDataImpl * >   (pedestalCollectionVec->getElementAt(  _ancillaryIndexMap[ sensorID ] ));
                
                
                //Noise
                TrackerDataImpl     * noise     = dynamic_cast < TrackerDataImpl * >   (noiseCollectionVec->getElementAt(  _ancillaryIndexMap[ sensorID ] ));
                
                
                if (inputRawData->getADCValues().size() != pedestal->getChargeValues().size()){
                    stringstream ss;
                    ss << "Input data and pedestal are incompatible\n"
                    << "Detector " << sensorID << " has " <<  inputRawData->getADCValues().size() << " pixels in the input data \n"
                    << "while " << pedestal->getChargeValues().size() << " in the pedestal data " << endl;
                    throw IncompatibleDataSetException(ss.str());
                }
                
                if (
                    //                   ( _siPlanesParameters->getSiPlanesType() == _siPlanesParameters->TelescopeWithoutDUT )
                    ////                   &&
                    //                   ( _siPlanesLayerLayout->getID(iDetector) == _DUT_ID ))
                    //                   &&
                    (sensorID == _DUT_ID))
                {
                    
                    //Raw Data, Pedestals & Noise
                    std::vector<short> adc_counts = inputRawData->getADCValues();
                    std::vector<float> pedestal_val = pedestal->getChargeValues();
                    std::vector<float> noise_val = noise->getChargeValues();
                    for (unsigned int i=0; i<384; i++) {
                        DUTadc_values[i] =  adc_counts[i]; //Assign vector to Array for stupid ROOT
                        DUTpedestal_values[i] = pedestal_val[i];
                        DUTnoise_values[i] = noise_val[i];
                    }
                    
                    zPosition = _siPlanesLayerLayout->getSensitivePositionZ(iDetector);
                    DUTevtno = evt->getEventNumber();
                    DUTData->Fill();
                    
                }
                
            }
            
            if (evt->getEventNumber()%1000==0) {
                streamlog_out (MESSAGE) << evt->getEventNumber() << " Events processed!" << std::endl;
            }
            
            if (evt->getEventNumber() == 1) {
                DUTPedeNoise->Fill();
            }
            
        }
        
        catch(DataNotAvailableException& e) 
        
        {
            streamlog_out  ( WARNING2 ) <<  "No input DUTData collection found on event " << event->getEventNumber()
            << " in run " << event->getRunNumber() << endl;
        }
    }
    
    
    _nEvt ++;
    
}



void DUTDataExporter::check( LCEvent * evt ) { 
    // nothing to check here - could be used to fill checkplots in reconstruction processor
}


void DUTDataExporter::end(){ 
    if ((Hitfile) && (!Hitfile->IsZombie())) {
        
        Hitfile->Write();
        Hitfile->Close();
        streamlog_out (MESSAGE) << "TFile Successfully written and closed!" << std::endl;
        
    }

}

