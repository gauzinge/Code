// Version: $Id: EUTelTiming.cc 2236 2013-01-14 15:00:54Z hperrey $
/* This file is actually empty */
