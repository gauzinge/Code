#include "HitExporter.h"
#include <iostream>
#include <string>

#include <EVENT/LCCollection.h>
#include <EVENT/MCParticle.h>

// ----- include for verbosity dependend logging ---------
#include "marlin/VerbosityLevels.h"

#ifdef MARLIN_USE_AIDA
#include <marlin/AIDAProcessor.h>
#include <AIDA/IHistogramFactory.h>
#include <AIDA/ICloud1D.h>
#include <AIDA/IHistogram1D.h>
#endif // MARLIN_USE_AIDA

// gear includes <.h>
#include <gear/GearMgr.h>
#include <gear/SiPlanesParameters.h>

// eutelescope includes ".h"
#include "EUTelAlignmentConstant.h"
#include "EUTELESCOPE.h"
#include "EUTelEventImpl.h"
#include "EUTelRunHeaderImpl.h"
#include "EUTelHistogramManager.h"
#include "EUTelExceptions.h"
#include "EUTelAPIXSparsePixel.h"
#include "EUTelSparseDataImpl.h"
#include "EUTelAPIXSparseClusterImpl.h"

// marlin includes ".h"
#include "marlin/Processor.h"
#include "marlin/Exceptions.h"
#include "marlin/Global.h"

// lcio includes <.h>
#include <UTIL/CellIDEncoder.h>
#include <UTIL/CellIDDecoder.h>
#include <EVENT/LCCollection.h>
#include <EVENT/LCEvent.h>
#include <IMPL/LCCollectionVec.h>
#include <IMPL/TrackerHitImpl.h>
#include <IMPL/TrackImpl.h>
#include <IMPL/TrackerDataImpl.h>
#include <IMPL/LCFlagImpl.h>
#include <Exceptions.h>

// aida includes <.h>
#include <marlin/AIDAProcessor.h>
#include <AIDA/IHistogramFactory.h>
#include <AIDA/IHistogram1D.h>
#include <AIDA/IHistogram2D.h>
#include <AIDA/IProfile1D.h>
#include <AIDA/IProfile2D.h>
#include <AIDA/ITree.h>

// ROOT includes:
#include "TVector3.h"
#include "TGraphErrors.h"
#include "TF1.h"
#include "TFitResultPtr.h"
#include "TFitResult.h"
#include "TMath.h"


using namespace lcio ;
using namespace marlin ;

using namespace std;
using namespace eutelescope;
using namespace gear;


HitExporter aHitExporter ;


HitExporter::HitExporter() : Processor("HitExporter") {

    // modify processor description
    _description = "HitExporter exports Telescope Hits ..." ;


  // first of all we need to register the input collection
//  registerInputCollection (LCIO::TRACKERHIT, "InputHitCollectionName",
//                           "The name of the input hit collection",
//                           _inputHitCollectionName, string ("corrhits"));
    
    registerInputCollection (LCIO::TRACK, "InputTrackCollectionName",
                             "The name of the input Track collection",
                             _inputTrackCollectionName, string ("Track"));
  
  registerProcessorParameter("Root File","This is the name of the file that will contain the TTrees with the Telescope Hits (add .root)",
                               _rootFile, static_cast< string > ( "Hits.root" ) );

}



void HitExporter::init() {
    
    streamlog_out(DEBUG) << "   init called  " << std::endl ;
    x0=0,y0=0,z0=0;
    x1=0,y1=0,z1=0;
    x2=0,y2=0,z2=0;
    x3=0,y3=0,z3=0;
    x4=0,y4=0,z4=0;
    x5=0,y5=0,z5=0;
    x6=0,y6=0,z6=0;
    x7=0,y7=0,z7=0;
    
    evtno=0;
    // usually a good idea to
    printParameters() ;
    file=new TFile(_rootFile.c_str(), "RECREATE");
    if (!file){
        streamlog_out( ERROR4 ) << "Can not create Root file!" << std::endl;
        throw UnknownDataTypeException("SORRY FOR QUITTING!");
    } else if (file->IsZombie()) {
        streamlog_out( ERROR4 ) << "Error opening Root file!" << std::endl;
        throw UnknownDataTypeException("SORRY FOR QUITTING!");
    } else {
        streamlog_out ( MESSAGE ) << "TFile successfully created!" << std::endl;
        TelescopeHit = new TTree ("TelescopeHit", "TTree with Telescope Hits in Telescope Frame of Reference");
        TelescopeHit->Branch("EventNo", &evtno,"EventNo/I");
        TelescopeHit->Branch("x0",&x0,"x0/D");
        TelescopeHit->Branch("y0",&y0,"y0/D");
        TelescopeHit->Branch("z0",&z0,"z0/D");
        
        TelescopeHit->Branch("x1",&x1,"x1/D");
        TelescopeHit->Branch("y1",&y1,"y1/D");
        TelescopeHit->Branch("z1",&z1,"z1/D");
        
        TelescopeHit->Branch("x2",&x2,"x2/D");
        TelescopeHit->Branch("y2",&y2,"y2/D");
        TelescopeHit->Branch("z2",&z2,"z2/D");
        
        TelescopeHit->Branch("x3",&x3,"x3/D");
        TelescopeHit->Branch("y3",&y3,"y3/D");
        TelescopeHit->Branch("z3",&z3,"z3/D");
        
        TelescopeHit->Branch("x4",&x4,"x4/D");
        TelescopeHit->Branch("y4",&y4,"y4/D");
        TelescopeHit->Branch("z4",&z4,"z4/D");
        
        TelescopeHit->Branch("x5",&x5,"x5/D");
        TelescopeHit->Branch("y5",&y5,"y5/D");
        TelescopeHit->Branch("z5",&z5,"z5/D");
        
        TelescopeHit->Branch("x6",&x6,"x6/D");
        TelescopeHit->Branch("y6",&y6,"y6/D");
        TelescopeHit->Branch("z6",&z6,"z6/D");
        
        TelescopeHit->Branch("x7",&x7,"x7/D");
        TelescopeHit->Branch("y7",&y7,"y7/D");
        TelescopeHit->Branch("z7",&z7,"z7/D");
    }
    _siPlanesParameters  = const_cast<SiPlanesParameters* > (&(Global::GEAR->getSiPlanesParameters()));
    _siPlanesLayerLayout = const_cast<SiPlanesLayerLayout*> ( &(_siPlanesParameters->getSiPlanesLayerLayout() ));
    
    _planePosition   = new double[8];
    
    for(int ipl=0; ipl <  _siPlanesLayerLayout->getNLayers(); ipl++)
    {
        _planePosition[ipl]=_siPlanesLayerLayout->getLayerPositionZ(ipl);
    }
}


void HitExporter::processRunHeader( LCRunHeader* run) {
//    auto_ptr<EUTelRunHeaderImpl> runHeader ( new EUTelRunHeaderImpl( run ));
//    runHeader->addProcessor( type() );
}



void HitExporter::processEvent( LCEvent * event ) {
    x0=0,y0=0,z0=0;
    x1=0,y1=0,z1=0;
    x2=0,y2=0,z2=0;
    x3=0,y3=0,z3=0;
    x4=0,y4=0,z4=0;
    x5=0,y5=0,z5=0;
    x6=0,y6=0,z6=0;
    x7=0,y7=0,z7=0;

    //-- note: this will not be printed if compiled w/o MARLINDEBUG=1 !
    
    if ( _nEvt %  10000 == 0 )
    {
        streamlog_out(DEBUG) << "   processing event: " << event->getEventNumber()
        << "   in run:  " << event->getRunNumber() << std::endl ;
    }
    
    EUTelEventImpl * evt = static_cast<EUTelEventImpl*> (event);
    
    
    if ( evt->getEventType() == kEORE )
    {
        streamlog_out ( DEBUG4 ) << "EORE found: nothing else to do." << endl;
        return;
    }
    else if ( evt->getEventType() == kUNKNOWN )
    {
        streamlog_out ( WARNING2 ) << "Event number " << evt->getEventNumber() << " in run " << evt->getRunNumber()
        << " is of unknown type. Continue considering it as a normal Data Event." << endl;
    }
    
//      try
//        {
//    
//            LCCollectionVec * inputCollectionVec         = dynamic_cast < LCCollectionVec * > (evt->getCollection(_inputHitCollectionName));
////            if (inputCollectionVec->size() <= 8) {
//    
//                for (size_t iHit = 0; iHit < inputCollectionVec->size(); iHit++) {
//                    TrackerHitImpl   * inputHit   = dynamic_cast< TrackerHitImpl * >  ( inputCollectionVec->getElementAt( iHit ) ) ;
//                       //  this is the loop over the input hit collection for this particular event
//                        double * inputPosition      = const_cast< double * > ( inputHit->getPosition() ) ; // and now I have the individual Hit
////                    streamlog_out (MESSAGE) << "x " << inputPosition[0] << " y " << inputPosition[1] << " z " << inputPosition[2] << std::endl;
//                    if (fabs(inputPosition[2]-_planePosition[0])<5) {
//                            x0=inputPosition[0];
//                            y0=inputPosition[1];
//                            z0=inputPosition[2];
//                            streamlog_out (MESSAGE) << "Found hit on plane 0 with " << x0 << " " << y0 << " " << z0 << std::endl;
//                        }
//                        else if (fabs(inputPosition[2]-_planePosition[1])<5) {
//                            x1=inputPosition[0];
//                            y1=inputPosition[1];
//                            z1=inputPosition[2];
//                            streamlog_out (MESSAGE) << "Found hit on plane 1 with " << x1 << " " << y1 << " " << z1 << std::endl;
//                        }
//                        else if (fabs(inputPosition[2]-_planePosition[2])<5) {
//                            x2=inputPosition[0];
//                            y2=inputPosition[1];
//                            z2=inputPosition[2];
//                            streamlog_out (MESSAGE) << "Found hit on plane 2 with " << x2 << " " << y2 << " " << z2 << std::endl;
//                        }
//                        else if (fabs(inputPosition[2]-_planePosition[3])<5) {
//                            x3=inputPosition[0];
//                            y3=inputPosition[1];
//                            z3=inputPosition[2];
//                            streamlog_out (MESSAGE) << "Found hit on plane 3 with " << x3 << " " << y3 << " " << z3 << std::endl;
//                        }
//                        else if (fabs(inputPosition[2]-_planePosition[4])<5) {
//                            x4=inputPosition[0];
//                            y4=inputPosition[1];
//                            z4=inputPosition[2];
//                            streamlog_out (MESSAGE) << "Found hit on plane 4 with " << x4 << " " << y4 << " " << z4 << std::endl;
//                        }
//                        else if (fabs(inputPosition[2]-_planePosition[5])<5) {
//                            x5=inputPosition[0];
//                            y5=inputPosition[1];
//                            z5=inputPosition[2];
//                            streamlog_out (MESSAGE) << "Found hit on plane 5 with " << x5 << " " << y5 << " " << z5 << std::endl;
//                        }
//                        else if (fabs(inputPosition[2]-_planePosition[6])<5) {
//                            x6=inputPosition[0];
//                            y6=inputPosition[1];
//                            z6=inputPosition[2];
//                            streamlog_out (MESSAGE) << "Found hit on plane 6 with " << x6 << " " << y6 << " " << z6 << std::endl;
//                        }
//                        else if (fabs(inputPosition[2]-_planePosition[7])<5) {
//                            x7=inputPosition[0];
//                            y7=inputPosition[1];
//                            z7=inputPosition[2];
//                            streamlog_out (MESSAGE) << "Found hit on plane 7 with " << x7 << " " << y7 << " " << z7 << std::endl;
//                        }
//                        evtno = evt->getEventNumber();
//                        TelescopeHit->Fill();
//                }
////            }
//            file->Flush();
//        }
//    catch (DataNotAvailableException& e) {
//        //streamlog_out  ( WARNING2 ) <<  "No input collection found on event " << event->getEventNumber()
//        //                            << " in run " << event->getRunNumber() << endl;
//    }
//    _nEvt ++ ;
//
//}

    if ((file) && (!file->IsZombie())) {
        
        //Telescope Tracks Loop
        try
        { //Make common try/catch??
            if ((evt->getEventNumber()) % 1000 ==0)
            {
                streamlog_out( MESSAGE ) << evt->getEventNumber() << " Events processed!" << std::endl;
                
            }
            
            LCCollection* inputTrackCollection         = dynamic_cast < LCCollection * > (evt->getCollection(_inputTrackCollectionName));
            
            for ( size_t iTrack = 0; iTrack < static_cast<size_t>(inputTrackCollection->getNumberOfElements()); iTrack++ ) //loops through tracks
                
            {
                TrackImpl * track = dynamic_cast<TrackImpl*> ( inputTrackCollection->getElementAt(iTrack) );
                TrackerHitVec hitvec = track->getTrackerHits(); //number of hit Planes
                
                for ( size_t iHit = 0; iHit < hitvec.size()  ; ++iHit ) //loops through hits in track
                {
                    
                    
                    TrackerHitImpl * hit;
                    if ( (hit = dynamic_cast<TrackerHitImpl*> ( hitvec[ iHit ] )) != 0x0 )
                    {
                        // show only original hit (type != 32)
                        if ( hit->getType() == 32 )
                        { streamlog_out (MESSAGE) << "I am a Fithit" << std::endl;
                        }
                        else {
                            //
                            if (fabs(static_cast< float > ( hit->getPosition()[2] )-_planePosition[0])<5) {
                                x0=static_cast< float > ( hit->getPosition()[0] );
                                y0=static_cast< float > ( hit->getPosition()[1] );
                                z0=static_cast< float > ( hit->getPosition()[2] );
                                streamlog_out (MESSAGE) << "Found hit on plane 0 with " << x0 << " " << y0 << " " << z0 << std::endl;
                            }
                            else if (fabs(static_cast< float > ( hit->getPosition()[2] )-_planePosition[1])<5) {
                                x1=static_cast< float > ( hit->getPosition()[0] );
                                y1=static_cast< float > ( hit->getPosition()[1] );
                                z1=static_cast< float > ( hit->getPosition()[2] );
                                streamlog_out (MESSAGE) << "Found hit on plane 1 with " << x1 << " " << y1 << " " << z1 << std::endl;
                            }
                            else if (fabs(static_cast< float > ( hit->getPosition()[2] )-_planePosition[2])<5) {
                                x2=static_cast< float > ( hit->getPosition()[0] );
                                y2=static_cast< float > ( hit->getPosition()[1] );
                                z2=static_cast< float > ( hit->getPosition()[2] );
                                streamlog_out (MESSAGE) << "Found hit on plane 2 with " << x2 << " " << y2 << " " << z2 << std::endl;
                            }
                            else if (fabs(static_cast< float > ( hit->getPosition()[2] )-_planePosition[3])<5) {
                                x3=static_cast< float > ( hit->getPosition()[0] );
                                y3=static_cast< float > ( hit->getPosition()[1] );
                                z3=static_cast< float > ( hit->getPosition()[2] );
                                streamlog_out (MESSAGE) << "Found hit on plane 3 with " << x3 << " " << y3 << " " << z3 << std::endl;
                            }
                            else if (fabs(static_cast< float > ( hit->getPosition()[2] )-_planePosition[4])<5) {
                                x4=static_cast< float > ( hit->getPosition()[0] );
                                y4=static_cast< float > ( hit->getPosition()[1] );
                                z4=static_cast< float > ( hit->getPosition()[2] );
                                streamlog_out (MESSAGE) << "Found hit on plane 4 with " << x4 << " " << y4 << " " << z4 << std::endl;
                            }
                            else if (fabs(static_cast< float > ( hit->getPosition()[2] )-_planePosition[5])<5) {
                                x5=static_cast< float > ( hit->getPosition()[0] );
                                y5=static_cast< float > ( hit->getPosition()[1] );
                                z5=static_cast< float > ( hit->getPosition()[2] );
                                streamlog_out (MESSAGE) << "Found hit on plane 5 with " << x5 << " " << y5 << " " << z5 << std::endl;
                            }
                            else if (fabs(static_cast< float > ( hit->getPosition()[2] )-_planePosition[6])<5) {
                                x6=static_cast< float > ( hit->getPosition()[0] );
                                y6=static_cast< float > ( hit->getPosition()[1] );
                                z6=static_cast< float > ( hit->getPosition()[2] );
                                streamlog_out (MESSAGE) << "Found hit on plane 6 with " << x6 << " " << y6 << " " << z6 << std::endl;
                            }
                            else if (fabs(static_cast< float > ( hit->getPosition()[2] )-_planePosition[7])<5) {
                                x7=static_cast< float > ( hit->getPosition()[0] );
                                y7=static_cast< float > ( hit->getPosition()[1] );
                                z7=static_cast< float > ( hit->getPosition()[2] );
                                streamlog_out (MESSAGE) << "Found hit on plane 7 with " << x7 << " " << y7 << " " << z7 << std::endl;
                            }
                        } //if != 32
//                        else streamlog_out (MESSAGE) << "x " << hit->getPosition()[0] << " y " <<hit->getPosition()[1] << " z " << hit->getPosition()[2] << " type " << hit->getType() << std::endl;
                    }
                }//hit for loop
            } //track loop
            evtno = evt->getEventNumber();
            TelescopeHit->Fill();
            file->Flush();
        } //try
        
        catch (DataNotAvailableException& e) {
            //streamlog_out  ( WARNING2 ) <<  "No input collection found on event " << event->getEventNumber()
            //                            << " in run " << event->getRunNumber() << endl;
        }
        _nEvt ++ ;
        
    }
}


void HitExporter::check( LCEvent * evt ) { 
    // nothing to check here - could be used to fill checkplots in reconstruction processor
}


void HitExporter::end(){ 
    file->Write();
    file->Close();
    streamlog_out (MESSAGE) << "TFile Successfully written and closed!" << std::endl;

    //   std::cout << "HitExporter::end()  " << name()
    // 	    << " processed " << _nEvt << " events in " << _nRun << " runs "
    // 	    << std::endl ;

}




